///////////////////////////////////////////////////////////////////////////////
//
// motion.h
//
// Purpose:   Declaration of classes related to motion.
//            Classes: DegreeOfFreedom, Motion.
//
// Created:   Jaroslav Semancik, 8/10/2003
//
///////////////////////////////////////////////////////////////////////////////

#ifndef MOTION_H
#define MOTION_H

///////////////////////////////////////////////////////////////////////////////
//
// class DegreeOfFreedom
//
// Class DegreeOfFreedom represents one time-varying degree-of-freedom (DOF)in
// an articulated figure as a continuous signal. Representation of the signal
// might be e.g. a piecewise linear polygon, a B-spline curve or a Fourier
// decomposition. It is constructed from given discrete uniform samples.
// The signal can be evaluated then in any time t; it handles even the cases
// when t > duration of the DOF or t < 0 (see the Evaluate method).
//
///////////////////////////////////////////////////////////////////////////////

class DegreeOfFreedom
{
public:

    string name;        // name of the DOF
    double duration;    // duration in seconds

    static bool wrap;   // state variable for evaluating DOFs
                        // wrap around for time out of duration?

    // Creates a DOF with name nam and duration dur from n_samples
    // uniformly spread samples stored in an array sample.

    DegreeOfFreedom(const string& nam, double dur,
        int n_samples, const double* sample) throw(invalid_argument);


    // Destroys the DOF - frees the memory allocated for the signal
    // representation.

    ~DegreeOfFreedom() throw();


    // Evaluates the signal at a given time.
    // In case that the time > duration of the DOF:
    //     it wraps around (i.e. modulo duration), if wrap state is true or
    //     returns the value at time == duration, if wrap state is false.
    // Similar behaviour occurs for time < 0.

    double Evaluate(double time) throw();


private:

    // Representation of the signal is currently a piecewise linear polygon
    // on the original samples.

    int n_knots;                // # of control points in the signal curve
    double *knot;               // array of knots
    double *vertex;             // array of control points (values in the knots)


    // Indices of control points used in last evaluation are cached for
    // speedup.

    bool cached;                // is current content of the cache valid?
    int cached_i1, cached_i2;   // cached indices of last used control points


    void build_from_samples(int n_samples, const double *sample) throw();
    double evaluate_polygon(double time) throw();
};



///////////////////////////////////////////////////////////////////////////////
//
// class Motion
//
// Class Motion represents a set of DOFs varying in one motion sequence. The
// DOFs are stored in an array and identified by index. That decouples models
// and motions allowing arbitrary linking of skeleton models with motion
// sequences.
//
///////////////////////////////////////////////////////////////////////////////

class Motion
{
public:

    string name;            // name of the motion
    double duration;        // duration in seconds

    int n_dofs;             // number of DOFs
    DegreeOfFreedom **dof;  // table of pointers to individual DOFs

    // Creates a motion with name nam, duration dur, number nd of
    // degrees-of-freedom and array of DOFs in d.

    Motion(const string& nam, double dur, int nd, DegreeOfFreedom** d);

    // Destructor - destroys all degrees-of-freedom in the motion first.

    ~Motion();

private:

};



///////////////////////////////////////////////////////////////////////////////
//
// global variables related to motion
//
///////////////////////////////////////////////////////////////////////////////
 

// array of all motions

// extern "C++" vector<Motion*> motions;

#endif

