///////////////////////////////////////////////////////////////////////////////
//
// wxmcv.cpp
//
// Purpose:   Implementation of wxWindows user interface for WX Motion Capture
//            Viewer 2. Main file of the program.
//            Classes: MyApp, MyFrame, MySplitter, AboutDialog.
//
// Created:   Jaroslav Semancik, 21/10/2003
//
///////////////////////////////////////////////////////////////////////////////

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif
#include <wx/glcanvas.h>
#include <wx/image.h>
#include <wx/splitter.h>

#include <string>
#include <sstream>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <stdexcept>
#include <math.h>
#include <list>
#include <vector>

using namespace std;

#include "base.h"
#include "vector.h"
#include "motion.h"
#include "skeleton.h"
#include "bvh.h"
#include "ogl.h"
#include "wxmcv.h"


// resources

#ifdef __WXMSW__
// resources are defined in wxmcv.rc
#else
    #include "resources/dancer.xpm"
    #include "resources/open.xpm"
    #include "resources/back.xpm"
    #include "resources/back_one.xpm"
    #include "resources/pause.xpm"
    #include "resources/fwd_one.xpm"
    #include "resources/fwd.xpm"
    #include "resources/reset.xpm"
    #include "resources/help.xpm"
#endif


// event tables and other macros for wxWindows

BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_MENU(ID_OPEN,               MyFrame::OnOpen)
    EVT_MENU(ID_CLOSE,              MyFrame::OnClose)
    EVT_MENU(ID_QUIT,               MyFrame::OnQuit)
    EVT_MENU(ID_BACK,               MyFrame::OnBack)
    EVT_MENU(ID_BACK_ONE,           MyFrame::OnBackOne)
    EVT_MENU(ID_PAUSE,              MyFrame::OnPause)
    EVT_MENU(ID_FWD_ONE,            MyFrame::OnFwdOne)
    EVT_MENU(ID_FWD,                MyFrame::OnFwd)
    EVT_MENU(ID_RESET_TIME,         MyFrame::OnResetTime)
    EVT_MENU(ID_RESET_VIEW,         MyFrame::OnResetView)
    EVT_MENU(ID_TOGGLE_CYCLE,       MyFrame::OnToggleCycle)
    EVT_MENU(ID_TOGGLE_SOLID,       MyFrame::OnToggleSolid)
    EVT_MENU(ID_TOGGLE_SHOWFILES,   MyFrame::OnToggleShowFiles)
    EVT_MENU(ID_TOGGLE_TOOLBAR,     MyFrame::OnToggleToolbar)
    EVT_MENU(ID_TOGGLE_STATUSBAR,   MyFrame::OnToggleStatusbar)
    EVT_MENU(ID_EXPORT,             MyFrame::OnExport)
    EVT_MENU(ID_ABOUT,              MyFrame::OnAbout)
    EVT_TIMER(ID_TIMER_FWD,         MyFrame::OnFwdOne)
    EVT_TIMER(ID_TIMER_BACK,        MyFrame::OnBackOne)
    EVT_TIMER(ID_TIMER_EXPORTING,   MyFrame::ExportFrame)
    EVT_CHECKLISTBOX(ID_FILELIST,   MyFrame::OnToggleShotCheckbox)
END_EVENT_TABLE()

IMPLEMENT_APP(MyApp)


// global variables

MyFrame *mainFrame;


///////////////////////////////////////////////////////////////////////////////
//
// class MyApp - public methods
//
///////////////////////////////////////////////////////////////////////////////

bool MyApp::OnInit()
{
    srand(time(NULL));

    // main application frame
    mainFrame = new MyFrame(_T("WX Motion Capture Viewer 2"),
                            wxDefaultPosition, wxDefaultSize);
    mainFrame->Show(true);
    SetTopWindow(mainFrame);
    return true;
}



///////////////////////////////////////////////////////////////////////////////
//
// class MyFrame - public methods
//
///////////////////////////////////////////////////////////////////////////////

MyFrame::MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size)
    : wxFrame((wxFrame*) NULL, -1, title, pos, size)
{
    SetIcon(wxICON(dancer));

#if wxUSE_MENUS
    // prepare menu
    build_menu();
#else
#error Recompile wxWindows with wxUSE_MENUS, wxUSE_GLCANVAS and wxUSE_TIMER set to 1 in setup.h
#endif

#if wxUSE_TOOLBAR
    // toolbar is visible by default
    recreate_toolbar();
#else
#message You should recompile wxWindows also with wxUSE_TOOLBAR and wxUSE_STATUSBAR set to 1 in setup.h
    m_toolBar = NULL;
#endif

#if wxUSE_STATUSBAR
    // statusbar is visible by default
    recreate_statusbar();
    SetStatusText(_T("Welcome to Motion Capture Viewer 2!"));
#else
#message You should recompile wxWindows also with wxUSE_TOOLBAR and wxUSE_STATUSBAR set to 1 in setup.h
    m_statusBar = NULL;
#endif

    // create splitter window
    m_splitter = new MySplitter(this);

    // create list for opened files
    m_fileList = new wxCheckListBox(m_splitter, ID_FILELIST,
        wxDefaultPosition, wxDefaultSize, 0, NULL, wxLB_MULTIPLE);

#if wxUSE_GLCANVAS
    // OpenGL drawing canvas
    glCanvas = new MyGLCanvas(m_splitter, -1, wxDefaultPosition,
        wxDefaultSize, wxSUNKEN_BORDER);
    glCanvas->InitGL();
#else
#error Recompile wxWindows with wxUSE_MENUS, wxUSE_GLCANVAS and wxUSE_TIMER set to 1 in setup.h
#endif

    // list of opened files is visible by deafault
    m_splitter->SplitVertically(m_fileList, glCanvas);

#if wxUSE_TIMER
    m_timer = new wxTimer();
#else
#error Recompile wxWindows with wxUSE_MENUS, wxUSE_GLCANVAS and wxUSE_TIMER set to 1 in setup.h
#endif

    // default settings
    cycle_anim = true;
    fwd_playing = true;
    time = 0;
    frametime = .04;    // 25 fps

    m_menuBar->Check(ID_TOGGLE_CYCLE, cycle_anim);
    m_menuBar->Check(ID_TOGGLE_SOLID, glCanvas->solid_rendering);

    // show time in 2-nd field of statusbar
    char s[20];
    sprintf(s, "Time: %8.3f s", time);
    SetStatusText(_T(s), 1);
}


// Shows standard open dialog to choose a file, load chosen BVH file and
// enable animation tools if correctly it has been loaded.

void MyFrame::OnOpen(wxCommandEvent& event)
{
    wxFileDialog *dlg = new wxFileDialog(this, _T("Open a motion file"),
        _T(""), _T(".bvh"),
        _T("Biovision hierarchy files (*.bvh)|*.bvh|All files (*.*)|*.*"),
        wxOPEN | wxFILE_MUST_EXIST | wxCHANGE_DIR );

    // exit unless a file is selected
    if (dlg->ShowModal() != wxID_OK) dlg->Destroy();

    SetStatusText(_T("Loading..."));

    // load a new skeleton and motion from a BVH file
    string path = string(dlg->GetDirectory());
    string name = string(dlg->GetFilename());
    BvhFile bvh(string(path + "/" + name));

    Joint *skeleton;
    Motion *motion;
    bool opened = bvh.Load(&skeleton, &motion);

    if (opened)
    {
        unsigned int r, g, b;

        r = rand() % 256;
        g = rand() % 256;
        b = rand() % 256;

        // create and a shot associating loaded skeleton and motion
        Shot *shot = new Shot(motion->name, skeleton, motion, r, g, b);

        // add new shot
        shots.push_back(shot);

        // add shot to the file list panel
        m_fileList->Append(motion->name.c_str());
        int i = m_fileList->GetCount() - 1;
        m_fileList->GetItem(i)->SetTextColour(wxColour(r, g, b));
        m_fileList->Check(i);

        // report info about shot to status bar
        stringstream s;
        s << name << "  / duration " << setprecision(5)
          << shot->motion->duration << " s /";
        SetStatusText(s.str().c_str(), 0);

        enable_animation_tools(true);

        // redisplay the scene
        glCanvas->DrawCheckedShots(m_fileList);
    }
    dlg->Destroy();
}


// Closes all selected shots in the filelist. Destroys respective shots,
// motions and skeletons. Disables animation tools if no shot remains open.

void MyFrame::OnClose(wxCommandEvent& event)
{
    // delete all checked shots and destroy them
    int n = m_fileList->GetCount();
    for (int i = n - 1; i >= 0; i--)
    	if (m_fileList->Selected(i))
        {
            m_fileList->Delete(i);
            delete shots[i];
            shots.erase(shots.begin() + i);
        }

    // disable animation tools if the file list is empty
    if (m_fileList->GetCount() == 0)
        enable_animation_tools(false);

    // redisplay the scene
    glCanvas->DrawCheckedShots(m_fileList);
}


// Destroys shots before terminating.

void MyFrame::OnQuit(wxCommandEvent& WXUNUSED(event))
{
    while (!shots.empty())
    {
        delete shots.back();
        shots.pop_back();
    }

    Close(true);
}


void MyFrame::OnResetTime(wxCommandEvent& WXUNUSED(event))
{
    time = 0;
    show_time();

    glCanvas->DrawCheckedShots(m_fileList);
}


void MyFrame::OnResetView(wxCommandEvent& WXUNUSED(event))
{
    glCanvas->SetInitialView();
    glCanvas->DrawCheckedShots(m_fileList);
}


void MyFrame::OnToggleCycle(wxCommandEvent& event)
{
    // switch cycle_anim
    cycle_anim = cycle_anim ? false : true;

    // set tools due to cycle_anim
    m_menuBar->Check(ID_TOGGLE_CYCLE, cycle_anim);
}


void MyFrame::OnToggleSolid(wxCommandEvent& WXUNUSED(event))
{
    // switch solid_rendering
    glCanvas->solid_rendering = glCanvas->solid_rendering ? false : true;

    // set tools due to solid_rendering
    m_menuBar->Check(ID_TOGGLE_SOLID, glCanvas->solid_rendering);

    // redraw scene with new setting
    glCanvas->DrawCheckedShots(m_fileList);
}


void MyFrame::OnToggleShowFiles(wxCommandEvent& WXUNUSED(event))
{
    bool show = m_menuBar->IsChecked(ID_TOGGLE_SHOWFILES);

    if (show)
    {
        m_fileList->Show(TRUE);
        glCanvas->Show(TRUE);
        m_splitter->SplitVertically(m_fileList, glCanvas);
    }
    else
        m_splitter->Unsplit(m_fileList);
}


void MyFrame::OnToggleShotCheckbox(wxCommandEvent& WXUNUSED(event))
{
    // redisplay the scene
    glCanvas->DrawCheckedShots(m_fileList);
}


void MyFrame::OnToggleToolbar(wxCommandEvent& WXUNUSED(event))
{
    bool show = m_menuBar->IsChecked(ID_TOGGLE_TOOLBAR);

    if (show)
        recreate_toolbar();
    else {
        delete m_toolBar;
        m_toolBar = NULL;
        SetToolBar(NULL);
    }

    // resize canvas
    wxSize client = this->GetClientSize();
    glCanvas->SetSize(client);
}


void MyFrame::OnToggleStatusbar(wxCommandEvent& WXUNUSED(event))
{
    bool show = m_menuBar->IsChecked(ID_TOGGLE_STATUSBAR);

    if (show)
        recreate_statusbar();
    else {
        delete m_statusBar;
        m_statusBar = NULL;
        SetStatusBar(NULL);
    }

    // resize canvas
    wxSize client = this->GetClientSize();
    m_splitter->SetSize(client);
}



void MyFrame::OnAbout(wxCommandEvent& WXUNUSED(event))
{
    AboutDialog *dlg = new AboutDialog(this);
    dlg->ShowModal();
}


void MyFrame::OnFwdOne(wxCommandEvent& WXUNUSED(event))
{
    time += frametime;
    show_time();

    glCanvas->DrawCheckedShots(m_fileList);
}


void MyFrame::OnBackOne(wxCommandEvent& WXUNUSED(event))
{
    time -= frametime;
    show_time();

    glCanvas->DrawCheckedShots(m_fileList);
}


void MyFrame::OnFwd(wxCommandEvent& WXUNUSED(event))
{
    SetStatusText(_T("Playing forward..."));
    fwd_playing = true;
    m_timer->SetOwner(this, ID_TIMER_FWD);
    m_timer->Start(int(frametime * 1000));  // time interval is in miliseconds
}


void MyFrame::OnBack(wxCommandEvent& WXUNUSED(event))
{
    SetStatusText(_T("Playing backwards..."));
    fwd_playing = false;
    m_timer->SetOwner(this, ID_TIMER_BACK);
    m_timer->Start(int(frametime * 1000));  // time interval is in miliseconds
}


void MyFrame::OnPause(wxCommandEvent& event)
{
    if (m_timer->IsRunning()) stop_animation();
    else
    {
        if (fwd_playing) OnFwd(event);
        else OnBack(event);
    }
}


// other public MyFrame methods related to recording and exporting
// of animation are in a separate file export.cpp


///////////////////////////////////////////////////////////////////////////////
//
// class MyFrame - private methods
//
///////////////////////////////////////////////////////////////////////////////

void MyFrame::build_menu()
{
    wxMenu *menuFile = new wxMenu;
    menuFile->Append(ID_OPEN, _T("&Open...\tO"), _T("Open a motion file"));
    menuFile->Append(ID_CLOSE, _T("&Close selected"), _T("Close selected motion files"));
    menuFile->AppendSeparator();
    menuFile->Append(ID_QUIT, _T("E&xit\tAlt-X"), _T("Quit this program"));

    wxMenu *menuAnim = new wxMenu;
    menuAnim->Append(ID_BACK, _T("Play &backwards\tCtrl-Left"), _T("Play animation backwards"));
    menuAnim->Append(ID_BACK_ONE, _T("B&ack one frame\tLeft"), _T("Play back one frame"));
    menuAnim->Append(ID_PAUSE, _T("&Pause\tSpace"), _T("Pause the animation"));
    menuAnim->Append(ID_FWD_ONE, _T("F&orward one frame\tRight"), _T("Play forward one frame"));
    menuAnim->Append(ID_FWD, _T("Play &forward\tCtrl-Right"), _T("Play animation forward"));
    menuAnim->AppendSeparator();
    menuAnim->Append(ID_RESET_TIME, _T("&Reset time\tT"), _T("Reset time to zero"));
    menuAnim->AppendCheckItem(ID_TOGGLE_CYCLE, _T("&Cycle animation\tC"), _T("Cycle/stop animation after last frame"));
    menuAnim->AppendSeparator();
    menuAnim->Append(ID_EXPORT, _T("&Export...\tE"), _T("Export all frames in animation as POV-Ray scene files"));

    wxMenu *menuView = new wxMenu;
    menuView->AppendCheckItem(ID_TOGGLE_SOLID, _T("&Solid redering\tS"), _T("Switch between solid and wireframe OpenGL rendering"));
    menuView->AppendSeparator();
    menuView->Append(ID_RESET_VIEW, _T("&Reset view\tV"), _T("Set the initial view to the scene"));
    menuView->AppendSeparator();
    menuView->AppendCheckItem(ID_TOGGLE_SHOWFILES, _T("Show opened files"), _T("Show/hide the list of opened files"));
    menuView->AppendCheckItem(ID_TOGGLE_TOOLBAR, _T("Show toolbar"), _T("Show/hide toolbar"));
    menuView->AppendCheckItem(ID_TOGGLE_STATUSBAR, _T("Show statusbar"), _T("Show/hide statusbar"));
    //defaults
    menuView->Check(ID_TOGGLE_SHOWFILES, true);
    menuView->Check(ID_TOGGLE_TOOLBAR, true);
    menuView->Check(ID_TOGGLE_STATUSBAR, true);

    wxMenu *menuHelp = new wxMenu;
    menuHelp->Append(ID_ABOUT, _T("&About...\tF1"), _T("Show dialog with program information"));

    m_menuBar = new wxMenuBar();
    m_menuBar->Append(menuFile, _T("&File"));
    m_menuBar->Append(menuAnim, _T("&Animation"));
    m_menuBar->Append(menuView, _T("&View"));
    m_menuBar->Append(menuHelp, _T("&Help"));

    SetMenuBar(m_menuBar);
    enable_animation_tools(false);
}


void MyFrame::recreate_toolbar()
{
    m_toolBar = CreateToolBar(wxTB_FLAT | wxTB_HORIZONTAL, ID_TOOLBAR);

    wxBitmap toolBarBitmaps[8];
    #ifdef __WXMSW__
        toolBarBitmaps[0] = wxBITMAP(open);
        toolBarBitmaps[1] = wxBITMAP(help);
        toolBarBitmaps[2] = wxBITMAP(back);
        toolBarBitmaps[3] = wxBITMAP(back_one);
        toolBarBitmaps[4] = wxBITMAP(stop);
        toolBarBitmaps[5] = wxBITMAP(fwd_one);
        toolBarBitmaps[6] = wxBITMAP(fwd);
        toolBarBitmaps[7] = wxBITMAP(reset);
    #else
        toolBarBitmaps[0] = wxBitmap(open_xpm);
        toolBarBitmaps[1] = wxBitmap(help_xpm);
        toolBarBitmaps[2] = wxBITMAP(back_xpm);
        toolBarBitmaps[3] = wxBITMAP(back_one_xpm);
        toolBarBitmaps[4] = wxBITMAP(stop_xpm);
        toolBarBitmaps[5] = wxBITMAP(fwd_one_xpm);
        toolBarBitmaps[6] = wxBITMAP(fwd_xpm);
        toolBarBitmaps[7] = wxBITMAP(reset_xpm);
    #endif // __WXMSW__

    m_toolBar->AddTool(ID_OPEN, _T("Open"), toolBarBitmaps[0], _T("Open file"));
    m_toolBar->AddSeparator();

    m_toolBar->AddTool(ID_BACK, _T("Back"), toolBarBitmaps[2], _T("Play backward"));
    m_toolBar->AddTool(ID_BACK_ONE, _T("Back 1 frame"), toolBarBitmaps[3], _T("Back 1 frame"));
    m_toolBar->AddTool(ID_PAUSE, _T("Pause"), toolBarBitmaps[4], _T("Pause the animation"));
    m_toolBar->AddTool(ID_FWD_ONE, _T("Forward 1 frame"), toolBarBitmaps[5], _T("Forward 1 frame"));
    m_toolBar->AddTool(ID_FWD, _T("Forward"), toolBarBitmaps[6], _T("Play forward"));
    m_toolBar->AddSeparator();

    m_toolBar->AddTool(ID_RESET_VIEW, _T("Reset"), toolBarBitmaps[7], _T("Reset view"));
    m_toolBar->AddSeparator();

    m_toolBar->AddTool(ID_ABOUT, _T("Help"), toolBarBitmaps[1], _T("Information about the program"));

    m_toolBar->Realize();
    enable_animation_tools(!shots.empty());
}


// enable/disable animation menu and tools due to en value

void MyFrame::enable_animation_tools(bool en)
{
    // en/dis Animation menu
    m_menuBar->EnableTop(1, en);

    // en/dis animation buttons on toolbar
    if (m_toolBar != NULL) {
        m_toolBar->EnableTool(ID_BACK, en);
        m_toolBar->EnableTool(ID_BACK_ONE, en);
        m_toolBar->EnableTool(ID_PAUSE, en);
        m_toolBar->EnableTool(ID_FWD_ONE, en);
        m_toolBar->EnableTool(ID_FWD, en);
        m_toolBar->EnableTool(ID_RESET_VIEW, en);
    }
}


void MyFrame::recreate_statusbar()
{
    m_statusBar = CreateStatusBar(2);
}


void MyFrame::stop_animation()
{
    SetStatusText(_T("Stop"));
    m_timer->Stop();
}


// show current time in 2-nd field of statusbar

void MyFrame::show_time()
{
    char s[30];
    sprintf(s, "Time: %8.3f s", time);
    SetStatusText(_T(s), 1);
}

// other private MyFrame methods related to recording and exporting
// of animation are in a separate file export.cpp



///////////////////////////////////////////////////////////////////////////////
//
// class MySplitter - public methods
//
///////////////////////////////////////////////////////////////////////////////

BEGIN_EVENT_TABLE(MySplitter, wxSplitterWindow)
    EVT_SPLITTER_SASH_POS_CHANGED(-1, MySplitter::OnPositionChanged)
END_EVENT_TABLE()

MySplitter::MySplitter(wxWindow *parent)
    : wxSplitterWindow(parent, -1, wxDefaultPosition, wxDefaultSize,
    wxCLIP_CHILDREN)
{
    m_position = 100;
    SetMinimumPaneSize(20);
}


bool MySplitter::SplitVertically(wxWindow* win1, wxWindow* win2)
{
    return wxSplitterWindow::SplitVertically(win1, win2, m_position);
}


void MySplitter::OnPositionChanged(wxSplitterEvent& event)
{
    m_position = GetSashPosition();
//    event.Skip();
}



/////////////////////////////////////////////////////////////////////////////
//
// class AboutDialog - about dialog
//
/////////////////////////////////////////////////////////////////////////////

AboutDialog::AboutDialog(wxWindow *parent)
    : wxDialog(parent, -1, "About WX Motion Capture Viewer 2", wxDefaultPosition,
               wxSize(250,165), wxDEFAULT_DIALOG_STYLE)// | wxRESIZE_BORDER )
{
    wxBoxSizer *dialogSizer = new wxBoxSizer(wxVERTICAL);

    // icon, title and author area
    wxBoxSizer *titleSizer = new wxBoxSizer(wxHORIZONTAL);
    wxStaticBitmap *iconBitmap = new wxStaticBitmap(this, -1, wxICON(dancer),
        wxPoint(0, 0), wxSize(32, 32));
    wxStaticText *titleText = new wxStaticText(this, -1,
        _T("WX Motion Capture Viewer 2\n\n")
        _T("by Jaroslav Semancik, 2003"),
        wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT);
    titleSizer->Add(iconBitmap, 0, wxTOP | wxLEFT | wxRIGHT, 20);
    titleSizer->Add(titleText, 1, wxTOP, 15);

    // program description area
    wxBoxSizer *descSizer = new wxBoxSizer(wxHORIZONTAL);
    wxStaticText *descText = new wxStaticText(this, -1,
        _T("A viewer for .bvh motion files, with export to\n")
        _T("free ray tracer POV-Ray (www.povray.org)."),
        wxDefaultPosition, wxDefaultSize, wxALIGN_CENTER);
    descSizer->Add(descText, 1, wxTOP, 10);

    // OK button
    wxBoxSizer *buttonSizer = new wxBoxSizer(wxHORIZONTAL);
    wxButton *okButton = new wxButton(this, wxID_OK, "Ok", wxPoint(-1, -1));
    buttonSizer->Add(okButton, 1, wxLEFT | wxRIGHT, 80);

    // vertical list of elements above
    dialogSizer->Add(titleSizer, 0, wxGROW);
    dialogSizer->Add(descSizer, 0, wxGROW);
    dialogSizer->Add(0, 10, 1);
    dialogSizer->Add(buttonSizer, 0, wxGROW);
    dialogSizer->Add(0, 10, 0);
    SetSizer(dialogSizer);
    SetAutoLayout(true);
    Layout();
}

