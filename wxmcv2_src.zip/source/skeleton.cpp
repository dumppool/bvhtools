///////////////////////////////////////////////////////////////////////////////
//
// skeleton.cpp
//
// Purpose:   Implementation of classes related to an articulated figure
//            (or skeleton) model.
//            Classes: Joint.
//
// Created:   Jaroslav Semancik, 13/10/2003
//
///////////////////////////////////////////////////////////////////////////////

// #define DEBUG

#include <wx/wx.h>
#include <wx/glcanvas.h>

#include <string>
#include <sstream>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>

using namespace std;

#include "base.h"
#include "vector.h"
#include "motion.h"
#include "skeleton.h"
#include "ogl.h"


///////////////////////////////////////////////////////////////////////////////
//
// class Joint - public methods
//
///////////////////////////////////////////////////////////////////////////////

// Creates a joint with name nam, rest position rest_pos, rest rotation
// rest_rot and degree-of-freedom indices to motion table for position and
// rotation in pos_dof, rot_dof respectively. The joint is created with no
// childrena and no parent. They must be added by AddChild method.

Joint::Joint(const string& nam, const Vector& rest_pos, const Vector& rest_rot,
             const IntVector& pos_dof, const IntVector& rot_dof) throw()
{
#ifdef DEBUG
    cout << "Creating joint " << nam << "...";
#endif

    name = nam;

    rest_position = rest_pos;
    rest_rotation = rest_rot;
    position_dof = pos_dof;
    rotation_dof = rot_dof;

    parent = NULL;
    n_children = 0;
    child = NULL;
    
#ifdef DEBUG
    cout << "OK" << endl;
#endif    
}


// Destructor - destroys recursively all joint's descendants first.

Joint::~Joint() throw()
{
#ifdef DEBUG
    cout << "Destroying joint " << name << "(" << endl;
#endif

    for (int i = 0; i < n_children; i++)
        delete child[i];

#ifdef DEBUG
    cout << ")";
#endif
}


// Add a joint chld as a direct descendant of the joint in the hierarchy
// and set the joint as a perent of the child.

void Joint::AddChild(Joint* chld) throw()
{
#ifdef DEBUG
    cout << "Adding child " << chld->name << " to joint " << name << "...";
#endif

    n_children++;
    
    child = (Joint**) realloc(child, n_children * sizeof(Joint**));

    child[n_children - 1] = chld;

    chld->parent = this;

#ifdef DEBUG
    cout << "OK" << endl;
#endif
}


// Draw the joint and its subhierarchy in a given motion and time.

void Joint::Draw(const Motion *motion, double time)
{
    Vector pos, rot;

    // evaluate instant position and rotation for the given motion and time
    eval_instant_position(pos, motion, time);
    eval_instant_rotation(rot, motion, time);

    // draw a segment from parent unless it is a root or the bone has zero
    // length
    if (parent && !ZERO(pos.length()))
        glCanvas->RenderLine(Vector(0.0, 0.0, 0.0), pos);

    // draw joint
    glCanvas->RenderPoint(pos);

    // draw joint's subhierarchy
    for (int i = 0; i < n_children; i++)
    {
        // save the parent's coordinate frame
        glPushMatrix();

        // transform from parent's to the joint's coordinate frame
        glTranslatef(pos.x, pos.y, pos.z);
        glRotatef(rot.z, 0.0, 0.0, 1.0);
        glRotatef(rot.x, 1.0, 0.0, 0.0);
        glRotatef(rot.y, 0.0, 1.0, 0.0);

        child[i]->Draw(motion, time);

        // restore the parent's coordinate frame
        glPopMatrix();
    }
}


// Export the joint and its subhierarchy in a given motion and time
// to a file as POV-Ray blob components.

void Joint::Export(ofstream& file, const Motion *motion, double time)
{
    Vector pos, rot;

    // evaluate instant position and rotation for the given motion and time
    eval_instant_position(pos, motion, time);
    eval_instant_rotation(rot, motion, time);

    if (parent && !ZERO(pos.length()))
    {
      	Matrix T;
       	glGetDoublev(GL_MODELVIEW_MATRIX, T.c);

        // transform segment endpoints to world coordinates
        Vector t_origin = Vector(0.0, 0.0, 0.0) * T;
        Vector t_pos = pos * T;

        // export segment from parent unless the joint is a root or degenerated
        file << "cylinder { <"
             << t_origin.x << ", " << t_origin.y << ", " << t_origin.z
             << ">, <" << t_pos.x << ", " << t_pos.y << ", " << t_pos.z
             << ">, th, 1 }" << endl;

        // write blob adjustment in the joint
        if (n_children > 0)
            file << "sphere { <"
                 << t_pos.x << ", " << t_pos.y << ", " << t_pos.z << ">, th, jnt }"
                 << endl;
    }

    // export joint's subhierarchy
    for (int i = 0; i < n_children; i++)
    {
        // save the parent's coordinate frame
        glPushMatrix();

        // transform from parent's to the bone's coordinate frame
        glTranslatef(pos.x, pos.y, pos.z);
        glRotatef(rot.z, 0.0, 0.0, 1.0);
        glRotatef(rot.x, 1.0, 0.0, 0.0);
        glRotatef(rot.y, 0.0, 1.0, 0.0);

        child[i]->Export(file, motion, time);

        // restore the parent's coordinate frame
        glPopMatrix();
    }
}



///////////////////////////////////////////////////////////////////////////////
//
// class Joint - private methods
//
///////////////////////////////////////////////////////////////////////////////

// Evaluates instant position of the joint in a given motion and time to
// vector result.

void Joint::eval_instant_position(Vector &result, const Motion *motion,
                                  double time)
{
    for (int i = 0; i < 3; i++)
    {
        if (position_dof.c[i] >= 0)
            result.c[i] = motion->dof[position_dof.c[i]]->Evaluate(time);
        else
            result.c[i] = rest_position.c[i];
    }
}


// Evaluates instant rotation of the joint in a given motion and time to
// vector result.

void Joint::eval_instant_rotation(Vector &result, const Motion *motion,
                                  double time)
{
    for (int i = 0; i < 3; i++)
    {
        if (rotation_dof.c[i] >= 0)
            result.c[i] = motion->dof[rotation_dof.c[i]]->Evaluate(time);
        else
            result.c[i] = rest_rotation.c[i];
    }
}



///////////////////////////////////////////////////////////////////////////////
//
// class Shot - public methods
//
///////////////////////////////////////////////////////////////////////////////

// Creates a shot of name nam with skeleton skel of rgb color (rr, gg, bb)
// associated with motion mot.

Shot::Shot(const string& nam, Joint* skel, Motion* mot,
    unsigned char rr, unsigned char gg, unsigned char bb) throw()
{
#ifdef DEBUG
    cout << "Creating shot " << nam << "...";
#endif

    name = nam;
    skeleton = skel;
    motion = mot;
    r = rr; g = gg; b = bb;
    
#ifdef DEBUG
    cout << "OK" << endl;
#endif
}


// Destructor - destroys associated skeleton and motion.

Shot::~Shot()
{
#ifdef DEBUG
    cout << "Destroying shot " << name << "...";
#endif

    delete skeleton;
    delete motion;

#ifdef DEBUG
    cout << "OK" << endl;
#endif
}


// Draw the shot in a given time and DOF wrapping state.

void Shot::Draw(double time, bool wrapping)
{
    // set wrapping state for evaluating of DOFs (static attribute)
    DegreeOfFreedom::wrap = wrapping;

    glColor3ub(r, g, b);

    // draw the skeleton with applied motion
    skeleton->Draw(motion, time);
}


// Export the shot in a given time to a given file.

void Shot::Export(ofstream& file, double time)
{
    if (time < 0 || time > motion->duration) return;

    // OpenGL matrix transformations are used to compute coordinates for export
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    skeleton->Export(file, motion, time);
}


///////////////////////////////////////////////////////////////////////////////
//
// global variables related to articulated figures
//
///////////////////////////////////////////////////////////////////////////////
 

// array of all skeletons

// vector<Joint*> skeletons;


// array of all shots

vector<Shot*> shots;

