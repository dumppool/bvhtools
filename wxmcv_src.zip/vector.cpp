///////////////////////////////////////////////////////////////////////////
//
// vector.cpp
//
// Purpose:   Implementation of operations on vectors, matrices
//
// Created:   Jaroslav Semancik, 01/07/2003
//
///////////////////////////////////////////////////////////////////////////

#include <math.h>
#include <iostream>

using namespace std;

#include "base.h"
#include "vector.h"

/////////////////////////////////////////////////////////////////////////////
// Vector methods
/////////////////////////////////////////////////////////////////////////////

// adjust vector to unit length

void Vector::normalize()
{
    float d = length();
    if (ZERO(d)) return;
    x /= d;
    y /= d;
    z /= d;
}


// Calculate length of the vector and rotation angles needed to align
// positive Z-axis onto vector direction. In x_rot and y_rot are angles
// (in radians!) to rotate around x-axis and y-axis respectively.

void Vector::polar(float& d, float& x_rot, float& y_rot) const
{
    d = length();
    float d2 = sqrt(x * x + z * z);
    if (!ZERO(d2))
    {
        x_rot = atan(-y / d2);
        y_rot = asin(x / d2);
        if (z < 0) y_rot = PI - y_rot;
    }
    else
    {
        x_rot = (y > 0) ? -PI/2 : PI/2;
        y_rot = 0;
    }
}


// operations on vectors

Vector operator + (const Vector& v1, const Vector& v2)
{
    return Vector(v1.x + v2.x, v1.y + v2.y, v1.z + v2.z);
}


Vector operator - (const Vector& v1, const Vector& v2)
{
    return Vector(v1.x - v2.x, v1.y - v2.y, v1.z - v2.z);
}


Vector operator - (const Vector& v)
{
    return Vector(-v.x, -v.y, -v.z);
}


Vector operator * (float k, const Vector& v)
{
    return Vector(k * v.x, k * v.y, k * v.z);
}


bool operator == (const Vector& v1, const Vector& v2)
{
    return (v1.x == v2.x && v1.y == v2.y && v1.z == v2.z);
}


// dot product

float dot(const Vector& v1, const Vector& v2)
{
    return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
}


// cross product

Vector cross(const Vector& v1, const Vector& v2)
{
    return Vector(v1.y * v2.z - v1.z * v2.y,
                  v1.z * v2.x - v1.x * v2.z,
                  v1.x * v2.y - v1.y * v2.x);
}


// angle of two vectors

float angle(const Vector& v1, const Vector& v2)
{
    float d1, d2, dp;

    d1 = v1.length();
    d2 = v2.length();
    if (ZERO(d1) || ZERO(d2)) return 0;

    dp = (v1.x * v2.x + v1.y * v2.y + v1.z * v2.z) / (d1 * d2);
    if (dp >= 1) return 0;
    if (dp <= -1) return PI;

    return acos(dp);
}


// print a vector

ostream& operator << (ostream& os, const Vector& v)
{
    return os << '(' << v.x << ", " << v.y << ", " << v.z << ')';
}


/////////////////////////////////////////////////////////////////////////////
// Matrix methods
/////////////////////////////////////////////////////////////////////////////

// constructor without params - create an identity matrix

Matrix::Matrix()
{
    int i;
    for (i = 0; i < 16; i++) c[i] = 0;
    for (i = 0; i < 16; i+=5) c[i] = 1;
}


// constructor with params - create a specified matrix

Matrix::Matrix(float m0, float m1, float m2, float m3, float m4, float m5, float m6, float m7,
               float m8, float m9, float m10, float m11, float m12, float m13, float m14, float m15)
{
    c[0] = m0;  c[1] = m1;  c[2] = m2;  c[3] = m3;
    c[4] = m4;  c[5] = m5;  c[6] = m6;  c[7] = m7;
    c[8] = m8;  c[9] = m9;  c[10] = m10;  c[11] = m11;
    c[12] = m12;  c[13] = m13;  c[14] = m14;  c[15] = m15;
}


// multiplication of vector v (with 4-th homogeneous coordinate = 1) by matrix M

Vector operator * (const Vector& v, const Matrix& m)
{
    Vector res;

    res.x = v.x * m.c[0] + v.y * m.c[4] + v.z * m.c[8] + m.c[12];
    res.y = v.x * m.c[1] + v.y * m.c[5] + v.z * m.c[9] + m.c[13];
    res.z = v.x * m.c[2] + v.y * m.c[6] + v.z * m.c[10] + m.c[14];

    return res;
}


// print a formated matrix

ostream& operator << (ostream& os, const Matrix& m)
{
    return os << endl << m.c[0] << "\t" << m.c[4] << "\t" << m.c[8] << '\t' << m.c[12]
              << endl << m.c[1] << "\t" << m.c[5] << "\t" << m.c[9] << '\t' << m.c[13]
              << endl << m.c[2] << "\t" << m.c[6] << "\t" << m.c[10] << '\t' << m.c[14]
              << endl << m.c[3] << "\t" << m.c[7] << "\t" << m.c[11] << '\t' << m.c[15]
              << endl;
}

