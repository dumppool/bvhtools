///////////////////////////////////////////////////////////////////////////////
//
// vector.h
//
// Purpose:   Declaration of classes for mathematics of vectors, matrices,
//            quaternions, etc.
//            Classes: Vector, IntVector, Matrix.
//
// Created:   Jaroslav Semancik, 13/10/2003
//
///////////////////////////////////////////////////////////////////////////////

#ifndef VECTOR_H
#define VECTOR_H

///////////////////////////////////////////////////////////////////////////////
//
// union Vector
//
// A class for vector of 3 real components. It can be accesed both as
// a structure of x, y, z coordinates and an array of c[0], c[1], c[2]
// coordinates. Usual operators are overloaded.  
//
///////////////////////////////////////////////////////////////////////////////

union Vector
{
    struct { double x, y, z; };
    double c[3];

    Vector(double xx = 0.0, double yy = 0.0, double zz = 0.0)
        : x(xx), y(yy), z(zz) {}
    ~Vector() {};

    Vector& operator += (const Vector& v)                   // V += V
        { x += v.x; y += v.y; z += v.z; return *this; }

    Vector& operator -= (const Vector& v)                   // V -= V
        { x -= v.x; y -= v.y; z -= v.z; return *this; }

    Vector& operator *= (double k)                          // V *= k
        { x *= k; y *= k; z *= k; return *this; }

    double length() const                                   // d = V.length()
        { return sqrt(x * x + y * y + z * z); }

    void normalize();                                       // V.normalize()

    // V.polar(d, x_rot, y_rot)
    void polar(double& d, double& x_rot, double& y_rot) const;
};

// operations on vectors

Vector operator + (const Vector& v1, const Vector& v2);
Vector operator - (const Vector& v1, const Vector& v2);
Vector operator - (const Vector& v);
Vector operator * (double k, const Vector& v);
bool operator == (const Vector& v1, const Vector& v2);
double dot(const Vector& v1, const Vector& v2);
Vector cross(const Vector& v1, const Vector& v2);
double angle(const Vector& v1, const Vector& v2);
ostream& operator << (ostream& os, const Vector& v);



///////////////////////////////////////////////////////////////////////////////
//
// union IntVector
//
// Vector of 3 integer components useful for indices. Only a small reasonable
// set of operators is implemented.
//
///////////////////////////////////////////////////////////////////////////////

union IntVector
{
    struct { int x, y, z; };
    int c[3];
    
    IntVector(int xx = -1, int yy = -1, int zz = -1)
        : x(xx), y(yy), z(zz) {}
    ~IntVector() {};

};

// operations on integer vectors

bool operator == (const IntVector& v1, const IntVector& v2);
ostream& operator << (ostream& os, const IntVector& v);



///////////////////////////////////////////////////////////////////////////////
//
// struct Matrix
//
// Class for 4x4 matrix. For transformations in 3D, compatible with matrix
// representation in OpenGL. 
//
///////////////////////////////////////////////////////////////////////////////

struct Matrix
{
    double c[16];

    Matrix();
    Matrix(double m0, double m1, double m2, double m3,
           double m4, double m5, double m6, double m7,
           double m8, double m9, double m10, double m11,
           double m12, double m13, double m14, double m15);
    ~Matrix() {};
};

Vector operator * (const Vector& v, const Matrix& m);
ostream& operator << (ostream& os, const Matrix& m);

#endif

