///////////////////////////////////////////////////////////////////////////
//
// ogl.h
//
// Purpose:   Declaration of wxWindows canvas for drawing by OpenGL
//
// Created:   Jaroslav Semancik, 01/07/2003
//
///////////////////////////////////////////////////////////////////////////


class MyGLCanvas: public wxGLCanvas
{
public:
    bool m_solid_rendering;     // solid or wireframe OpenGL rendering

    MyGLCanvas(wxWindow *parent, const wxWindowID id = -1, const wxPoint& pos = wxDefaultPosition,
        const wxSize& size = wxDefaultSize, long style = 0, const wxString& name = "MyGLCanvas");
    ~MyGLCanvas();
    void InitGL();
    void SetInitialView();
    void OnSize(wxSizeEvent& event);
    void OnPaint(wxPaintEvent& event);
    void OnMouse(wxMouseEvent& event);
    void RenderPoint(const Vector& p,
                     float r = 1.0, float g = .85, float b = .2, float a = 1.0);
    void RenderLine(const Vector& p1, const Vector& p2,
                    float r = 1.0, float g = .85, float b = .2, float a = 1.0);
    void DrawSkeletons();

private:
    // projection
    float m_fovy, m_near, m_far;

    // current transformation of the scene
    Matrix m_rotation;
    Vector m_translation;

    // display lists
    int m_grid_dl, m_skeletons_dl;

    // mouse position
    wxPoint m_last_mouse;

    // methods
    void draw_grid();

    DECLARE_EVENT_TABLE()
};

// global drawing canvas

extern "C++" MyGLCanvas *glCanvas;

