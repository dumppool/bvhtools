///////////////////////////////////////////////////////////////////////////
//
// bvh.h
//
// Purpose:   BVH file format parser - class declaration
//
// Created:   Jaroslav Semancik, 26/06/2003
//
///////////////////////////////////////////////////////////////////////////

#ifndef BVH_H
#define BVH_H

class parse_error: public runtime_error
{
public:
    parse_error(const string& s): runtime_error(s) {}
};


class BVH
{
private:
    string filename;
    ifstream file;

    string token;
    int line;

    string bone_name;
    Vector bone_offset;

public:
    BVH(const string &fn) { filename = fn; }
    bool Load() throw();

private:
    void read_next_token() throw(parse_error);
    bool token_is(const string& tok) throw();
    void take_token(const string& tok) throw(parse_error);
    void token_to_string(string& str) throw(parse_error);
    void token_to_float(float& num) throw(parse_error);
    void token_to_int(int& num) throw(parse_error);

    void parse_bvh() throw(parse_error, out_of_range);
    void parse_hierarchy() throw(parse_error);
    void parse_root() throw(parse_error);
    void parse_joint(Bone *parent) throw(parse_error);
    void parse_joint_data(Bone *parent) throw(parse_error);
    void parse_end_site(Bone *parent) throw(parse_error);
    void parse_offset() throw(parse_error);
    void parse_channels(Bone *bone) throw(parse_error);
    void parse_motion() throw(parse_error, out_of_range);
    void parse_motion_data() throw(parse_error, out_of_range);
};

#endif

