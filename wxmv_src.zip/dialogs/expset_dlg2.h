/*
 * expset_dlg2.h
 * Window identifiers file written by Dialog Editor
 */

#define ID_TEXTCTRL101 101
#define ID_TEXTCTRL110 110
#define ID_TEXTCTRL104 104
#define ID_TEXTCTRL105 105
#define ID_TEXTCTRL106 106
#define ID_TEXTCTRL107 107
#define ID_TEXTCTRL108 108
#define ID_TEXTCTRL109 109
#define ID_STATICBOX102 102
#define ID_STATICBOX103 103
#define ID_DIALOG100 100
#define ID_STATIC111 111
#define ID_STATIC112 112
#define ID_STATIC113 113
#define ID_STATIC114 114
#define ID_STATIC115 115
#define ID_STATIC116 116
#define ID_STATIC117 117
#define ID_BUTTON118 118
#define ID_BUTTON119 119
