///////////////////////////////////////////////////////////////////////////////
//
// export.cpp
//
// Purpose:   Implementation of main frame MyFrame methods related to
//            exporting of animation.
//
// Created:   Jaroslav Semancik, 27/10/2003
//
///////////////////////////////////////////////////////////////////////////////

#include <wx/wx.h>
#include <wx/glcanvas.h>
#include <wx/image.h>
#include <wx/splitter.h>

#include <string>
#include <sstream>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <stdexcept>
#include <math.h>
#include <list>
#include <vector>
#include <io.h>

using namespace std;

#include "base.h"
#include "vector.h"
#include "motion.h"
#include "skeleton.h"
#include "bvh.h"
#include "ogl.h"
#include "wxmcv.h"


///////////////////////////////////////////////////////////////////////////////
//
// MyFrame - public methods related to export
//
///////////////////////////////////////////////////////////////////////////////

void MyFrame::OnExport(wxCommandEvent& event)
{
    // choose output directory by a common dialog
    wxFileDialog *dlg = new wxFileDialog(this, _T("Export to file..."),
        _T(""), _T(".inc"),
        _T("POV-Ray include files (*.inc)|*.inc|All files (*.*)|*.*"),
        wxSAVE | wxOVERWRITE_PROMPT );

    if (dlg->ShowModal() != wxID_OK) return;

    m_export_path = string(dlg->GetDirectory());
    m_inc_name = string(dlg->GetFilename());
    dlg->Destroy();

    // find a maximal duration of any checked shot
    m_max_dur = 0;
    int n = m_fileList->GetCount();
    for (int i = 0; i < n; i++)
    	if (m_fileList->IsChecked(i) && shots[i]->motion->duration > m_max_dur)
    	   m_max_dur = shots[i]->motion->duration;

    // set .ini and .pov file names
    m_ini_name = m_inc_name;
    StripExtension(m_ini_name);
    m_pov_name = m_ini_name + ".pov";
    m_ini_name += ".ini";

    // create directories for exported files
    create_directories();

    // create .inc file including an .inc file for particular shots and frames
    if (!create_inc_file()) return;

    // create POV-Ray .ini file with animation settings
    if (!create_ini_file()) return;

    SetStatusText(_T("Exporting animation..."));

    // export first frame
    OnResetTime(event);
    m_frame_number = 0;
    if (!ExportFrame(event)) return;

    // set timer to export all remaining frames
    fwd_playing = true;
    m_timer->SetOwner(this, ID_TIMER_EXPORTING);
    m_timer->Start(int(frametime * 1000));      // time interval in miliseconds

}


// This function is periodically called by timer when exporting animation.
// It stores current pose of a skeleton as a set of POV-Ray blob components
// to an .inc file for each checked shot and frame and increments time.
// Returns whether a frame has been successfully exported.

bool MyFrame::ExportFrame(wxCommandEvent& event)
{
    // is the whole animation already exported?
    if (time > m_max_dur)
    {
    	stop_animation();
    	return true;
    }

    // create an .inc file for each checked shot
    int n = m_fileList->GetCount();
    for (int i = 0; i < n; i++)
    {
    	if (!m_fileList->IsChecked(i)) continue;
    	if (time > shots[i]->motion->duration) continue;

        // create file name for current frame
        string filename = frame_filename(shots[i], m_frame_number);
        filename = m_export_path + "/" + shots[i]->name + "/" + filename;
        ofstream file;

        // open file for write
        file.open(filename.c_str());
        if (!file)
        {
            stop_animation();

            stringstream error;
            error << "Unable to create file " << filename
                  << ". Disk full or write protection?";
            ErrorMessage(error.str());

            return false;
        }

        // write header comments
        write_frame_header(file, shots[i], m_frame_number);

        // write segments of a skeleton in the shot
        shots[i]->Export(file, time);

        file.close();
    }

    OnFwdOne(event);
    m_frame_number++;
    return true;
}



///////////////////////////////////////////////////////////////////////////////
//
// MyFrame - private methods related to export
//
///////////////////////////////////////////////////////////////////////////////

// Creates directories for exported file. A directory for each shot is
// created to contain all its frame .inc files. Moreover an ./out directory
// is created for output images rendered by POV-Ray.
// Does not check whether directories have been successfully created.

void MyFrame::create_directories()
{
    string dirname;

    // create a directory for frame .inc files of each checked shot
    int n = m_fileList->GetCount();
    for (int i = 0; i < n; i++)
    {
        if (!m_fileList->IsChecked(i)) continue;

        dirname = m_export_path + "/" + shots[i]->name;
        mkdir(dirname.c_str());
    }

    // create ./out directory for POV-Ray output images
    dirname = m_export_path + "/out";
    mkdir(dirname.c_str());
    return;
}



// Create a main .inc file to be included from POV-Ray scene. This file
// contains a POV-Ray blob object for each checked shot. Inside the blob
// a particular .inc file is included containing blob components for
// a skeleton posture in just rendered frame.
// Returns whether the file has been successfully created.

bool MyFrame::create_inc_file()
{
    string filename = m_export_path + "/" + m_inc_name;
    ofstream file;

    // open file for write
    file.open(filename.c_str());
    if (!file)
    {
    	stringstream error;
        error << "Unable to create file " << filename << ". Disk full or write protection?";
        ErrorMessage(error.str());
        return false;
    }

    // write initial comments
    file << "//" << endl
         << "// " << m_inc_name << " - main include file with skeletons as a POV-Ray blobs" << endl
         << "//" << endl
         << "// Use in your scene by: " << endl
         << "//" << endl
         << "//     #include \"" << m_inc_name << "\"" << endl
         << "//" << endl
         << "// and set animation .ini file for POV-Ray rendering to " << m_ini_name << endl
         << "//" << endl
         << "// Generated by Motion Capture Viewer 2" << endl
         << "//" << endl
         << "//////////////////////////////////////////////////////////////////////" << endl
         << endl;

    // write adjustable constants
    file << "#declare th = 1.5;      // thickness of bones" << endl
         << "#declare jnt = -0.9;  // blob adjustment in joints" << endl;

    // write a blob object for each checked shot
    int n = m_fileList->GetCount();
    for (int i = 0; i < n; i++)
    {
    	if (!m_fileList->IsChecked(i)) continue;

		// color components to float range <0,1>
        float r = (float)shots[i]->r / 255;
	    float g = (float)shots[i]->g / 255;
	    float b = (float)shots[i]->b / 255;

        // number of frames for this shot and its width
	    int nf = (int)((shots[i]->motion->duration + EPSILON) / frametime);
        int w = (int)log10((float)nf) + 1;

        // write blob
        file << endl << endl
             << "// " << shots[i]->name << " shot" << endl << endl
             << "blob {" << endl
             << "    threshold .5" << endl;

        if (cycle_anim)
            file << endl<< "    #declare fn = mod(frame_number, " << nf
                   << ");" << endl;
        else
            file << "    #declare fn = (frame_number < " << nf
                   << " ? frame_number : " << nf - 1 << ");" << endl;

        file << "    #declare incname = " << "concat(\"" << shots[i]->name
               << "/" << shots[i]->name << "\", str(fn, " << -w
               << ", 0), \".inc\");" << endl
             << "    #include incname" << endl
             << endl
             << "    texture {               // YOU MAY CHANGE MATERIAL HERE"
               << endl
             << "        pigment { color < "
               << setprecision(3) << r << ", " << g << ", " << b << " > }"
               << endl
             << "        finish { specular 0.9  roughness 0.01 }" << endl
             << "    }" << endl
             << "}" << endl;
    }

    file.close();
    return true;
}



// Create a POV-Ray .ini file with animation settings.
// Returns whether the file has been successfully created.

bool MyFrame::create_ini_file()
{
    string filename = m_export_path + "/" + m_ini_name;
    ofstream file;

    // open file for write
    file.open(filename.c_str());
    if (!file)
    {
    	stringstream error;
        error << "Unable to create file " << filename << ". Disk full or write protection?";
        ErrorMessage(error.str());
        return false;
    }

    // write initial comments
    file << ";" << endl
         << "; " << m_ini_name << " - POV-Ray animation settings" << endl
         << "; (framerate: " << 1 / frametime << " fps)" << endl
         << ";" << endl
         << "; For settings description see POV-Ray documention" << endl
         << ";" << endl
         << "; Generated by Motion Capture Viewer 2" << endl
         << ";" << endl
         << ";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;" << endl
         << endl;

    // max. number of frames
    int max_nf = (int)((m_max_dur + EPSILON) / frametime);

    // write animation settings
    file << "Input_File_Name=" << m_pov_name << endl
         << "Output_File_Name=./out/" << endl
         << endl
         << endl
         << "; animation settings" << endl
         << endl
         << "Initial_Frame=" << 0 << endl
         << "Final_Frame=" << max_nf - 1 << endl
         << "Cyclic_Animation=off" << endl
         << endl
         << endl
         << "; uncomment and set the following to render a particular frame(s)" << endl
         << endl
         << "; Subset_Start_Frame=" << endl
         << "; Subset_End_Frame=" << endl
         << endl
         << endl
         << "; output size" << endl
         << endl
         << "Width=320" << endl
         << "Height=240" << endl
         << endl
         << endl
         << ";antialiasing" << endl
         << endl
         << "Antialias=on         ; turn off for test renderings" << endl
         << "Sampling_Method=2" << endl
         << "Antialias_Depth=3" << endl
         << "Jitter=off" << endl;

    file.close();
    return true;
}


// Returns file name with .inc extension for a given shot and frame number.

string MyFrame::frame_filename(const Shot* shot, int fn)
{
    stringstream filename;

    int w = (int)log10((float)(shot->motion->duration + EPSILON) / frametime) + 1;
    filename << shot->name << setw(w) << setfill('0') << fn << ".inc";

    return filename.str();
}


// Writes comments in the beginning of each frame .inc file.

void MyFrame::write_frame_header(ofstream& file, const Shot* shot, int fn)
{
    file << "//" << endl
         << "// " << shot->name << ": frame " << fn
            << ",  blob components included from " << m_inc_name << endl
         << "//" << endl
         << "// Generated by Motion Capture Viewer 2" << endl
         << "//" << endl
         << "//////////////////////////////////////////////////////////" << endl
         << endl;
}

