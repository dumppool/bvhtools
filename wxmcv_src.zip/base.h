///////////////////////////////////////////////////////////////////////////
//
// base.h
//
// Purpose:   Fundamental data types and function declarations
//
// Created:   Jaroslav Semancik, 27/06/2003
//
///////////////////////////////////////////////////////////////////////////

#ifndef BASE_H
#define BASE_H

// some helpful math macros

#define EPSILON 0.000001
#define PI      3.141592653589793
#define R2D(x)  (180.0 * (x) / PI)      // radians to degrees conversion
#define D2R(x)  (PI * (x) / 180.0)      // degrees to radians conversion
#define SQR(x)  ((x) * (x))             // square root
#define ZERO(x) (fabs(x) < EPSILON)     // zero test for floating point numbers



// function for reporting messages and errors

void Message(const string& msg);

extern "C++" stringstream error;

#endif

