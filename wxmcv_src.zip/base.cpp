///////////////////////////////////////////////////////////////////////////
//
// base.cpp
//
// Purpose:   Implementation of fundamental functions
//            (maybe in a platform-dependent way)
//
// Created:   Jaroslav Semancik, 27/06/2003
//
///////////////////////////////////////////////////////////////////////////

#include <wx/wx.h>
#include <wx/image.h>

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <stdexcept>

using namespace std;

#include "wxmcv.h"
#include "base.h"

// function for reporting messages and errors
// implemented as message box under wxWindows

void Message(const string& msg)
{
    // wxWindows message box
    wxMessageBox(msg.c_str(), _T("Error"), wxOK | wxICON_ERROR, mainFrame);

    // simple output to console
//    cout << endl << msg;
}


// global variable to format errors into and call Message()

stringstream error;
