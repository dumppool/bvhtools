///////////////////////////////////////////////////////////////////////////
//
// skeleton.cpp
//
// Purpose:   implementation of classes for hierarchical skeleton handling
//
// Created:   Jaroslav Semancik, 25/06/2003
//
///////////////////////////////////////////////////////////////////////////

#include <wx/wx.h>
#include <wx/glcanvas.h>

#include <fstream>
#include <string>
#include <sstream>
#include <stdexcept>

using namespace std;

#include "base.h"
#include "vector.h"
#include "ogl.h"
#include "skeleton.h"


// bone id's starts from one

int Bone::next_id = 1;

///////////////////////////////////////////////////////////////////////////
// Bone - public methods
///////////////////////////////////////////////////////////////////////////

// constructor - create a bone with name nam, offset ofs and maybe flags flgs
// flags are implicitly 0

Bone::Bone(const string& nam, const Vector ofs, const unsigned long flgs)
{
    id = next_id;
    next_id++;

    name = nam;
    flags = flgs;

    offset = ofs;
    rotation = Vector(0, 0, 0);

    parent = child = sibling = NULL;
}


// destructor - delete the bone and all its succesors in the hierarchy

Bone::~Bone()
{
    Bone *csib;

    while (child)
    {
    	csib = child->sibling;
    	delete child;
    	child = csib;
    }
}


// return name of the bone

string Bone::GetName()
{
    return name;
}


// get pointer to bone offset values to connect channel data

Vector* Bone::GetOffsetPtr()
{
    return &(this->offset);
}


// get pointer to bone rotation values to connect channel data

Vector* Bone::GetRotationPtr()
{
    return &(this->rotation);
}


// add a child ch to the bone

void Bone::AddChild(Bone *ch)
{
    if (!ch) return;

    ch->parent = this;
    ch->sibling = child;
    child = ch;
}


// draw the bone and all its succesors in the hierarchy

void Bone::Draw()
{
    // draw parent's segment unless the bone is root
    if (parent) glCanvas->RenderLine(Vector(0.0, 0.0, 0.0), offset);

    // draw joint
    glCanvas->RenderPoint(offset);

    // draw bone's subhierarchy
    if (child)
    {
        // save the parent's coordinate frame
        glPushMatrix();

        // transform from parent's to the bone's coordinate frame
        glTranslatef(offset.x, offset.y, offset.z);
        glRotatef(rotation.z, 0.0, 0.0, 1.0);
        glRotatef(rotation.x, 1.0, 0.0, 0.0);
        glRotatef(rotation.y, 0.0, 1.0, 0.0);

        child->Draw();

        // restore the parent's coordinate frame
        glPopMatrix();
    }

    // draw siblings
    if (sibling) sibling->Draw();
}


// export the bone and all its succesors in the hierarchy to file
// as a POV-Ray blob component

void Bone::Export(ofstream& file)
{
  	Matrix T;
   	glGetFloatv(GL_MODELVIEW_MATRIX, T.c);

    Vector origin(0.0, 0.0, 0.0);
    Vector t_origin = origin * T;
    Vector t_offset = offset * T;

    // export parent's segment unless the bone is root or degenerated
    if (parent && !ZERO(offset.length()))
    {
        file << "cylinder { <"
             << t_origin.x << ", " << t_origin.y << ", " << t_origin.z << ">, <"
             << t_offset.x << ", " << t_offset.y << ", " << t_offset.z << ">, th, 1 }"
             << endl;
    }

    // export bone's subhierarchy
    if (child)
    {
        // write blob adjustment in the joint
        file << "sphere { <"
             << t_offset.x << ", " << t_offset.y << ", " << t_offset.z << ">, th, jnt }"
             << endl;

        // save the parent's coordinate frame
        glPushMatrix();

        // transform from parent's to the bone's coordinate frame
        glTranslatef(offset.x, offset.y, offset.z);
        glRotatef(rotation.z, 0.0, 0.0, 1.0);
        glRotatef(rotation.x, 1.0, 0.0, 0.0);
        glRotatef(rotation.y, 0.0, 1.0, 0.0);

        child->Export(file);

        // restore the parent's coordinate frame
        glPopMatrix();
    }

    // export siblings
    if (sibling) sibling->Export(file);
}


///////////////////////////////////////////////////////////////////////////
// SkeletonQueue - public methods
///////////////////////////////////////////////////////////////////////////

// destructor - delete entire queue

SkeletonQueue::~SkeletonQueue()
{
    Skeleton *s;

    while (head)
    {
    	s = head->next;
    	delete head;
    	head = s;
    }
}


// create skeleton with given root and add it to skeletons in the scene
// (enqueue it at the beginning of the queue)

void SkeletonQueue::AddSkeleton(Bone *root)
{
  	Skeleton *skel = new Skeleton(root);
    skel->next = head;
    head = skel;
}


// set current skeleton to first skeleton and return its pointer

Skeleton* SkeletonQueue::FirstSkeleton()
{
    current = head;
    return current;
}


// set current skeleton to next skeleton and return its pointer

Skeleton* SkeletonQueue::NextSkeleton()
{
    if (current)
        current = current->next;
    return current;
}


// draw all skeletons in the queue

void SkeletonQueue::Draw()
{
    Skeleton *skel;

    skel = skeletons->FirstSkeleton();
    while (skel)
    {
    	skel->Draw();
    	skel = skeletons->NextSkeleton();
    }
}


// export all skeletons in a queue as a set of POV-Ray blob components

void SkeletonQueue::Export(ofstream& file)
{
    Skeleton *skel;

    // OpenGL matrix transformations are used to compute coordinates for export
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    skel = skeletons->FirstSkeleton();
    while (skel)
    {
    	skel->Export(file);
    	skel = skeletons->NextSkeleton();
    }

}


///////////////////////////////////////////////////////////////////////////
// global variables related to a hierarchical skeleton
///////////////////////////////////////////////////////////////////////////

// pointer to a queue of all skeletons in the scene

SkeletonQueue *skeletons = NULL;

