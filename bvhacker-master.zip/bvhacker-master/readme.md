This is the readme file for the bvhacker open source project.

Please see bvhacker.com for more details.