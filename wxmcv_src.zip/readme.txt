

          W X   M o t i o n   C a p t u r e   V i e w e r

                    by Jaroslav Semancik, 2003

                    Charles University, Prague


WXMCV is a program for viewing and playing .bvh (Biovision Hierarchy)
motion files written in C++ with use of wxWindows for graphical user
interface and OpenGL for visualization of a model. Thus the program is
rather portable and can be compiled for any common platform (maybe
after some minor adjustments of the source). Free multiplatform GUI
toolkit wxWindows (www. wixwindows.org) provides a native look on each
platform. Biovision Hierarchy file format is described in file bvh.txt.

Export to popular free raytracer POV-Ray (www.povray.org) is useful for
final rendering of an animation.


    /// POV-Ray export ///

In menu Animation select Export and choose a directory for scene files
output. The entire animation is exported while playing on the screen at
the same time. A main include file is produced which you include in
your POV-Ray scene. Besides, a separate include file for each frame is
generated which is included by the main file automatically when
rendering corresponding frame. The model is exported as a POV-Ray blob
ensuring continuous surface and no cracks around joints. Blob threshold
and joint bulginess can be modified in the main include file. A camera,
lights and other scene settings as well as a blob texture are all
specified in your scene.

Note that also a POV-Ray .ini file is generated to control the
animation. You must set it as an .ini file for the scene in your
POV-Ray environment before rendering. It contains some basic rendering
settings and you can edit it to your needs.

Do not be surprised that "Cycle animation" is turned off in WXMCV after
exporting  of an animation.


    /// Source code and compilation comments ///

The source is organized as follows:

wxmcv.h, wxmcv.cpp       - main file, contains wxWindows user interface,
                           application and main frame classes
export.cpp               - export related methods of the main frame class
skeleton.h, skeleton.cpp - skeleton data structures and methods
motion.h, motion.cpp     - manipulation with motion channels
bvh.h, bvh.cpp           - loading and parsing of input .bvh file
ogl.h, ogl.cpp           - visualization using OpenGL
vector.h, vector.cpp     - classes for vectors and matrices, with
                           overloaded operators
base.h, base.cpp         - fundamental staff useful for all modules
wxmcv.rc                 - resources description on MS Windows
makefile.wx              - makefile (for a wxWindows program)
bvh.txt                  - BVH file format description

To compile the source code you need to install and compile wxWindows
with enabled use of menus and glCanvas (and also toolbar and statusbar
is recommended) in wxWindows setup.h of your platform. Then make sure
that compiler options are set to enable exceptions in an .env file (in
wxWindows ./src directory) that is dependent on compiler you plan to
use. Finally edit the makefile.wx to include a proper makefile from
wxWindows installation according to your compiler.

Note that the standard C++ string class is used for strings in the
program preventing to take care about string lengths.


    // BVH file parsing //

A .bvh file is parsed by class BVH (in files bvh.h and bvh.c).
BVH class uses exceptions mechanism for parse errors handling.
All whitespace is skipped and alignement of the file is not
significant. Valid characters are

+-.0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_:{}

and characters +-{} can appear only as the first character of a token.
Thus if one of them occurs, reading of previous token is stopped.

A syntax gramatics used to parse BVH file is

.bvh        -> [hierarchy] [motion] end-of-file
hierarchy   -> "HIERARCHY" (root)*
root        -> "ROOT" name { joint-data }
joint       -> "JOINT" name { joint-data }
joint-data  -> offset [channels] (joint/end-site)+
end-site    -> "End" "Site" { offset }
offset      -> "OFFSET" float float float
channels    -> "CHANNELS" int (Xposition/Yposition/Zposition/Xrotation/Yrotation/Zrotation)*
motion      -> "MOTION" "Frames:" int "Frame" "Time:" float motion-data
motion-data -> (float)*

where

[item]   means an optional item
"token"  means token (without quotes) in the input file
foo/bar  means either foo or bar
(item)*  means any number (including zero) of items
(item)+  means at least one item
{        means { in the input file (as well for } )

So parser does not report any error if the HIERARCHY or MOTION section
misses completely in a .bvh file. The parser correctly handles also
multiple ROOT nodes in HIERARCHY section yielding several separated
skeletons.

Data structures of a hierarchical skeleton(s) and motion channels are
beeing created during parsing as they are encountered in the file.


    // Data structures //

A skeleton is a tree structure of bones (class Bone). A bone is
strongly affected by BVH format and it represents a joint in fact. It
contains translational offset relative to its parent coordinate system
and rotations around individual axes. Note that rotations are applied in
Z,X,Y order as .bvh format states. Motion channels are binded to the
rotations which are initialized to zero regardless of initial skeleton
posture (offsets suffice to catch it). A bone contains pointers to its
parent, to its sibling and to a first child. All childs are thus linked
in a list through siblings. Each bone has a name and unique ID (int)
except end-effector bones (end sites) all with ID=0 and flag END_SITE.
IDs are automatiacally assigned in bone constructor using a class
(static) variable.

The skeleton (class Skeleton) contains pointer to ist root bone. All
skeletons in the scene are stored in a linked list (class
SkeletonQueue). The Bone, Skeleton and SkeltonQueue classes are defined
in files skeleton.h and skeleton.cpp.

The motion is streamed in channels (class Channel). A channel contains
name, pointer to a target variable (one of rotation or offset
components) and an array of target variable values in individual frames.
Channels are created and targeted together with skeleton creation
during HIERARCHY section parsing, but their size is allocated and data
loaded later - in MOTION section, where number of frames will become
known. Request for channel data outside its size (number of frames)
causes an out-of-range exception.

All channels together in a linked list form a motion (class Motion).
Class Motion provides methods to set a particular frame, i.e. to write
i-th value of each channel to its target in a skeleton. Classes Channel
and Motion are defined in files motion.h and motion.cpp.


    // Visualization //

Real-time visualization of the skeleton motion is performed by OpenGL.
The whole scene can be translated, rotated or scaled by mouse movements
and buttons. Rendering and OpenGL setup functions are managed by class
MyGLCanvas (in files ogl.h and ogl.cpp) derived from wxWindows class
wxGLCanvas. A recursive  processing of bones in the skeleton is
implemented in a Bone's Draw method, however. OpenGL matrix
transformation capabilities are used, as well as for exporting of the
skeleton or potentially any recursive processing of the skeleton's
bones. Note the rotation order Z,X,Y given by .bvh format specification.

