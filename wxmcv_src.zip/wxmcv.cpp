///////////////////////////////////////////////////////////////////////////
//
// wxmcv.cpp
//
// Purpose:   Implementation of wxWindows user interface for WX Motion Capture Viewer.
//            Main file of the program.
//
// Created:   Jaroslav Semancik, 06/05/2003
//
///////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// headers
/////////////////////////////////////////////////////////////////////////////

#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif
#include <wx/glcanvas.h>
#include <wx/image.h>

#include <math.h>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>
#include <stdexcept>

using namespace std;

#include "base.h"
#include "vector.h"
#include "skeleton.h"
#include "motion.h"
#include "bvh.h"
#include "ogl.h"
#include "wxmcv.h"


/////////////////////////////////////////////////////////////////////////////
// resources
/////////////////////////////////////////////////////////////////////////////

#ifdef __WXMSW__
// resources are defined in wxmcv.rc
#else
    #include "resources/dancer.xpm"
    #include "resources/open.xpm"
    #include "resources/back.xpm"
    #include "resources/back_one.xpm"
    #include "resources/pause.xpm"
    #include "resources/fwd_one.xpm"
    #include "resources/fwd.xpm"
    #include "resources/reset.xpm"
    #include "resources/help.xpm"
#endif

/////////////////////////////////////////////////////////////////////////////
// event tables and other macros for wxWindows
/////////////////////////////////////////////////////////////////////////////

BEGIN_EVENT_TABLE(MyFrame, wxFrame)
    EVT_MENU(ID_OPEN,               MyFrame::OnOpen)
    EVT_MENU(ID_QUIT,               MyFrame::OnQuit)
    EVT_MENU(ID_BACK,               MyFrame::OnBack)
    EVT_MENU(ID_BACK_ONE,           MyFrame::OnBackOne)
    EVT_MENU(ID_PAUSE,              MyFrame::OnPause)
    EVT_MENU(ID_FWD_ONE,            MyFrame::OnFwdOne)
    EVT_MENU(ID_FWD,                MyFrame::OnFwd)
    EVT_MENU(ID_GO_TO_FIRST_FRAME,  MyFrame::OnGoToFirstFrame)
    EVT_MENU(ID_RESET_VIEW,         MyFrame::OnResetView)
    EVT_MENU(ID_TOGGLE_CYCLE,       MyFrame::OnToggleCycle)
    EVT_MENU(ID_TOGGLE_SOLID,       MyFrame::OnToggleSolid)
    EVT_MENU(ID_TOGGLE_TOOLBAR,     MyFrame::OnToggleToolbar)
    EVT_MENU(ID_TOGGLE_STATUSBAR,   MyFrame::OnToggleStatusbar)
    EVT_MENU(ID_RECORD,             MyFrame::OnRecord)
    EVT_MENU(ID_EXPORT,             MyFrame::OnExport)
    EVT_MENU(ID_ABOUT,              MyFrame::OnAbout)
    EVT_TIMER(ID_TIMER_FWD,         MyFrame::OnFwdOne)
    EVT_TIMER(ID_TIMER_BACK,        MyFrame::OnBackOne)
    EVT_TIMER(ID_TIMER_RECORDING,   MyFrame::SaveFrame)
    EVT_TIMER(ID_TIMER_EXPORTING,   MyFrame::ExportFrame)
END_EVENT_TABLE()

IMPLEMENT_APP(MyApp)


/////////////////////////////////////////////////////////////////////////////
//
// implementation
//
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// MyApp - the application class
/////////////////////////////////////////////////////////////////////////////

MyFrame *mainFrame;

bool MyApp::OnInit()
{
    // main application frame
    mainFrame = new MyFrame(_T("WX Motion Capture Viewer"),
                            wxDefaultPosition, wxDefaultSize);
    mainFrame->Show(true);
    SetTopWindow(mainFrame);

#if wxUSE_GLCANVAS
    // OpenGL drawing canvas
    glCanvas = new MyGLCanvas(mainFrame, -1, wxDefaultPosition,
        wxDefaultSize, wxSUNKEN_BORDER);
    glCanvas->InitGL();
#else
#error Recompile wxWindows with wxUSE_MENUS, wxUSE_GLCANVAS and wxUSE_TIMER set to 1 in setup.h
#endif

    // reflect default values of state variables to menu items
    // must be called after glCanvas is created
    mainFrame->SetDefaults();
    return true;
}


/////////////////////////////////////////////////////////////////////////////
// MyFrame - main frame public methods
/////////////////////////////////////////////////////////////////////////////

MyFrame::MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size)
       : wxFrame((wxFrame*) NULL, -1, title, pos, size)
{
    SetIcon(wxICON(dancer));

#if wxUSE_MENUS
    // prepare menu
    build_menu();
#else
#error Recompile wxWindows with wxUSE_MENUS, wxUSE_GLCANVAS and wxUSE_TIMER set to 1 in setup.h
#endif

#if wxUSE_TOOLBAR
    // prepare toolbar
    recreate_tool_bar();
#else
#message You should recompile wxWindows also with wxUSE_TOOLBAR and wxUSE_STATUSBAR set to 1 in setup.h
    m_toolBar = NULL;
#endif

#if wxUSE_STATUSBAR
    // prepare statusbar
    recreate_status_bar();
    SetStatusText(_T("Welcome to Motion Capture Viewer!"));
#else
#message You should recompile wxWindows also with wxUSE_TOOLBAR and wxUSE_STATUSBAR set to 1 in setup.h
    m_statusBar = NULL;
#endif

#if wxUSE_STATUSBAR
    m_timer = new wxTimer();
#else
#error Recompile wxWindows with wxUSE_MENUS, wxUSE_GLCANVAS and wxUSE_TIMER set to 1 in setup.h
#endif

    // for saving to PNG format
    m_image.AddHandler(new wxPNGHandler);

    // cycle animation by default
    m_cycle = true;
    m_fwd = true;
}


// reflect default values of state variables to menu items

void MyFrame::SetDefaults()
{
    if (!glCanvas) return;

    m_menuBar->Check(ID_TOGGLE_CYCLE, m_cycle);
    m_menuBar->Check(ID_TOGGLE_SOLID, glCanvas->m_solid_rendering);
}


// show standard open dialog to choose a file
// load chosen .bvh file
// enable animation tools if correctly loaded

void MyFrame::OnOpen(wxCommandEvent& event)
{
    wxFileDialog *dlg = new wxFileDialog(this, _T("Open a motion file"),
        _T(""), _T(".bvh"),
        _T("Biovision hierarchy files (*.bvh)|*.bvh|All files (*.*)|*.*"),
        wxOPEN | wxFILE_MUST_EXIST);

    if (dlg->ShowModal() == wxID_OK)
    {
        // load a .bvh file
        SetStatusText(_T("Loading..."));
        m_bvhpath = dlg->GetDirectory();
        m_bvhname = dlg->GetFilename();

        BVH bvh(string(m_bvhpath + "/" + m_bvhname));
        m_opened = bvh.Load();

        if (m_opened)
        {
            enable_animation_tools();
        	SetStatusText(dlg->GetFilename(), 0);

            // set skeletons to first frame pose and display
        	motion->FirstFrame();
        	glCanvas->DrawSkeletons();
        }
    }
    dlg->Destroy();
}


void MyFrame::OnQuit(wxCommandEvent& WXUNUSED(event))
{
    if (motion) delete motion;
    if (skeletons) delete skeletons;
    motion = NULL;
    skeletons = NULL;
    Close(true);
}


void MyFrame::OnGoToFirstFrame(wxCommandEvent& WXUNUSED(event))
{
    motion->FirstFrame();
    glCanvas->DrawSkeletons();
}


void MyFrame::OnResetView(wxCommandEvent& WXUNUSED(event))
{
    glCanvas->SetInitialView();
    glCanvas->DrawSkeletons();
}


void MyFrame::OnToggleCycle(wxCommandEvent& event)
{
    // switch m_cycle
    m_cycle = m_cycle ? false : true;

    // set tools due to m_cycle
    m_menuBar->Check(ID_TOGGLE_CYCLE, m_cycle);
}


void MyFrame::OnToggleSolid(wxCommandEvent& WXUNUSED(event))
{
    // switch m_solid_rendering
    glCanvas->m_solid_rendering = glCanvas->m_solid_rendering ? false : true;

    // set tools due to m_solid_rendering
    m_menuBar->Check(ID_TOGGLE_SOLID, glCanvas->m_solid_rendering);

    // redraw scene with new setting
    glCanvas->DrawSkeletons();
}


void MyFrame::OnToggleToolbar(wxCommandEvent& WXUNUSED(event))
{
    bool show = m_menuBar->IsChecked(ID_TOGGLE_TOOLBAR);

    if (show)
        recreate_tool_bar();
    else {
        delete m_toolBar;
        m_toolBar = NULL;
        SetToolBar(NULL);
    }

    // resize canvas
    wxSize client = mainFrame->GetClientSize();
    glCanvas->SetSize(client);
}


void MyFrame::OnToggleStatusbar(wxCommandEvent& WXUNUSED(event))
{
    bool show = m_menuBar->IsChecked(ID_TOGGLE_STATUSBAR);

    if (show)
        recreate_status_bar();
    else {
        delete m_statusBar;
        m_statusBar = NULL;
        SetStatusBar(NULL);
    }

    // resize canvas
    wxSize client = mainFrame->GetClientSize();
    glCanvas->SetSize(client);
}


void MyFrame::OnAbout(wxCommandEvent& WXUNUSED(event))
{
    AboutDialog *dlg = new AboutDialog(this);
    dlg->ShowModal();
}


void MyFrame::OnFwdOne(wxCommandEvent& WXUNUSED(event))
{
    motion->NextFrame();
    glCanvas->DrawSkeletons();
}


void MyFrame::OnBackOne(wxCommandEvent& WXUNUSED(event))
{
    motion->PreviousFrame();
    glCanvas->DrawSkeletons();
}


void MyFrame::OnFwd(wxCommandEvent& WXUNUSED(event))
{
    SetStatusText(_T("Playing forward..."));
    m_fwd = true;
    m_timer->SetOwner(mainFrame, ID_TIMER_FWD);
    m_timer->Start(int(motion->frame_time * 1000));  // time interval in miliseconds
}


void MyFrame::OnBack(wxCommandEvent& WXUNUSED(event))
{
    SetStatusText(_T("Playing backwards..."));
    m_fwd = false;
    m_timer->SetOwner(mainFrame, ID_TIMER_BACK);
    m_timer->Start(int(motion->frame_time * 1000));  // time interval in miliseconds
}


void MyFrame::OnPause(wxCommandEvent& event)
{
    if (m_timer->IsRunning()) StopAnimation();
    else
    {
        if (m_fwd) OnFwd(event);
        else OnBack(event);
    }
}


void MyFrame::StopAnimation()
{
    SetStatusText(_T("Stop"));
    m_timer->Stop();
}


// other public MyFrame methods related to recording and exporting
// of animation are in a separate file export.cpp


/////////////////////////////////////////////////////////////////////////////
// MyFrame - main frame private methods
/////////////////////////////////////////////////////////////////////////////

void MyFrame::build_menu()
{
    wxMenu *menuFile = new wxMenu;
    menuFile->Append(ID_OPEN, _T("&Open...\tO"), _T("Open a motion file"));
    menuFile->AppendSeparator();
    menuFile->Append(ID_QUIT, _T("E&xit\tAlt-X"), _T("Quit this program"));

    wxMenu *menuAnim = new wxMenu;
    menuAnim->Append(ID_BACK, _T("Play &backwards\tCtrl-Left"), _T("Play animation backwards"));
    menuAnim->Append(ID_BACK_ONE, _T("B&ack one frame\tLeft"), _T("Play back one frame"));
    menuAnim->Append(ID_PAUSE, _T("&Pause\tSpace"), _T("Pause the animation"));
    menuAnim->Append(ID_FWD_ONE, _T("F&orward one frame\tRight"), _T("Play forward one frame"));
    menuAnim->Append(ID_FWD, _T("Play &forward\tCtrl-Right"), _T("Play animation forward"));
    menuAnim->AppendSeparator();
    menuAnim->Append(ID_GO_TO_FIRST_FRAME, _T("&Go to first frame\tF"), _T("Go to first frame of the animation"));
    menuAnim->AppendCheckItem(ID_TOGGLE_CYCLE, _T("&Cycle animation\tC"), _T("Cycle/stop animation after last frame"));
    menuAnim->AppendSeparator();
    menuAnim->Append(ID_RECORD, _T("Recor&d...\tD"), _T("Save screenshots of all frames in animation"));
    menuAnim->Append(ID_EXPORT, _T("&Export...\tE"), _T("Export all frames in animation as POV-Ray scene files"));

    wxMenu *menuView = new wxMenu;
    menuView->AppendCheckItem(ID_TOGGLE_SOLID, _T("&Solid redering\tS"), _T("Switch between solid and wireframe OpenGL rendering"));
    menuView->AppendSeparator();
    menuView->Append(ID_RESET_VIEW, _T("&Reset view\tR"), _T("Set the initial view to the scene"));
    menuView->AppendSeparator();
    menuView->AppendCheckItem(ID_TOGGLE_TOOLBAR, _T("Show toolbar"), _T("Show/hide toolbar"));
    menuView->AppendCheckItem(ID_TOGGLE_STATUSBAR, _T("Show statusbar"), _T("Show/hide statusbar"));
    menuView->Check(ID_TOGGLE_TOOLBAR, true);
    menuView->Check(ID_TOGGLE_STATUSBAR, true);

    wxMenu *menuHelp = new wxMenu;
    menuHelp->Append(ID_ABOUT, _T("&About...\tF1"), _T("Show dialog with program information"));

    m_menuBar = new wxMenuBar();
    m_menuBar->Append(menuFile, _T("&File"));
    m_menuBar->Append(menuAnim, _T("&Animation"));
    m_menuBar->Append(menuView, _T("&View"));
    m_menuBar->Append(menuHelp, _T("&Help"));

    SetMenuBar(m_menuBar);
    enable_animation_tools();
}


void MyFrame::recreate_tool_bar()
{
    m_toolBar = CreateToolBar(wxTB_FLAT | wxTB_HORIZONTAL, ID_TOOLBAR);

    wxBitmap toolBarBitmaps[8];
    #ifdef __WXMSW__
        toolBarBitmaps[0] = wxBITMAP(open);
        toolBarBitmaps[1] = wxBITMAP(help);
        toolBarBitmaps[2] = wxBITMAP(back);
        toolBarBitmaps[3] = wxBITMAP(back_one);
        toolBarBitmaps[4] = wxBITMAP(stop);
        toolBarBitmaps[5] = wxBITMAP(fwd_one);
        toolBarBitmaps[6] = wxBITMAP(fwd);
        toolBarBitmaps[7] = wxBITMAP(reset);
    #else
        toolBarBitmaps[0] = wxBitmap(open_xpm);
        toolBarBitmaps[1] = wxBitmap(help_xpm);
        toolBarBitmaps[2] = wxBITMAP(back_xpm);
        toolBarBitmaps[3] = wxBITMAP(back_one_xpm);
        toolBarBitmaps[4] = wxBITMAP(stop_xpm);
        toolBarBitmaps[5] = wxBITMAP(fwd_one_xpm);
        toolBarBitmaps[6] = wxBITMAP(fwd_xpm);
        toolBarBitmaps[7] = wxBITMAP(reset_xpm);
    #endif // __WXMSW__

    m_toolBar->AddTool(ID_OPEN, _T("Open"), toolBarBitmaps[0], _T("Open file"));
    m_toolBar->AddSeparator();

    m_toolBar->AddTool(ID_BACK, _T("Back"), toolBarBitmaps[2], _T("Play backward"));
    m_toolBar->AddTool(ID_BACK_ONE, _T("Back 1 frame"), toolBarBitmaps[3], _T("Back 1 frame"));
    m_toolBar->AddTool(ID_PAUSE, _T("Pause"), toolBarBitmaps[4], _T("Pause the animation"));
    m_toolBar->AddTool(ID_FWD_ONE, _T("Forward 1 frame"), toolBarBitmaps[5], _T("Forward 1 frame"));
    m_toolBar->AddTool(ID_FWD, _T("Forward"), toolBarBitmaps[6], _T("Play forward"));
    m_toolBar->AddSeparator();

    m_toolBar->AddTool(ID_RESET_VIEW, _T("Reset"), toolBarBitmaps[7], _T("Reset view"));
    m_toolBar->AddSeparator();

    m_toolBar->AddTool(ID_ABOUT, _T("Help"), toolBarBitmaps[1], _T("Information about the program"));

    m_toolBar->Realize();
    enable_animation_tools();
}


// enable/disable animation menu and tools due to an animation is opened

void MyFrame::enable_animation_tools()
{
    // en/dis Animation menu
    if (m_menuBar != NULL)
        m_menuBar->EnableTop(1, m_opened);

    // en/dis animation buttons on toolbar
    if (m_toolBar != NULL) {
        m_toolBar->EnableTool(ID_BACK, m_opened);
        m_toolBar->EnableTool(ID_BACK_ONE, m_opened);
        m_toolBar->EnableTool(ID_PAUSE, m_opened);
        m_toolBar->EnableTool(ID_FWD_ONE, m_opened);
        m_toolBar->EnableTool(ID_FWD, m_opened);
        m_toolBar->EnableTool(ID_RESET_VIEW, m_opened);
    }
}


void MyFrame::recreate_status_bar()
{
    m_statusBar = CreateStatusBar(2);
}


// other private MyFrame methods related to recording and exporting
// of animation are in a separate file export.cpp


/////////////////////////////////////////////////////////////////////////////
// AboutDialog - about dialog
/////////////////////////////////////////////////////////////////////////////

AboutDialog::AboutDialog(wxWindow *parent)
    : wxDialog(parent, -1, "About WX Motion Capture Viewer", wxDefaultPosition,
               wxSize(250,165), wxDEFAULT_DIALOG_STYLE)// | wxRESIZE_BORDER )
{
    wxBoxSizer *dialogSizer = new wxBoxSizer(wxVERTICAL);

    // icon, title and author area
    wxBoxSizer *titleSizer = new wxBoxSizer(wxHORIZONTAL);
    wxStaticBitmap *iconBitmap = new wxStaticBitmap(this, -1, wxICON(dancer),
        wxPoint(0, 0), wxSize(32, 32));
    wxStaticText *titleText = new wxStaticText(this, -1,
        _T("WX Motion Capture Viewer\n\n")
        _T("by Jaroslav Semancik, 2003"),
        wxDefaultPosition, wxDefaultSize, wxALIGN_LEFT);
    titleSizer->Add(iconBitmap, 0, wxTOP | wxLEFT | wxRIGHT, 20);
    titleSizer->Add(titleText, 1, wxTOP, 15);

    // program description area
    wxBoxSizer *descSizer = new wxBoxSizer(wxHORIZONTAL);
    wxStaticText *descText = new wxStaticText(this, -1,
        _T("A viewer for .bvh motion files, with export to\n")
        _T("free ray tracer POV-Ray (www.povray.org)."),
        wxDefaultPosition, wxDefaultSize, wxALIGN_CENTER);
    descSizer->Add(descText, 1, wxTOP, 10);

    // OK button
    wxBoxSizer *buttonSizer = new wxBoxSizer(wxHORIZONTAL);
    wxButton *okButton = new wxButton(this, wxID_OK, "Ok", wxPoint(-1, -1));
    buttonSizer->Add(okButton, 1, wxLEFT | wxRIGHT, 80);

    // vertical list of elements above
    dialogSizer->Add(titleSizer, 0, wxGROW);
    dialogSizer->Add(descSizer, 0, wxGROW);
    dialogSizer->Add(0, 10, 1);
    dialogSizer->Add(buttonSizer, 0, wxGROW);
    dialogSizer->Add(0, 10, 0);
    SetSizer(dialogSizer);
    SetAutoLayout(true);
    Layout();
}

