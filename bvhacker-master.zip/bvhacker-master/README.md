bvhacker
========

bvhacker is the notepad equivalent for bvh animation files. Please see bvhacker.com for more details.

I started bvhacker a long time ago, and have learnt a lot on the way. Consequently, some of the older code is not perhaps optimsed as best it could be. Contructive critism only please!

I've decided to make bvhacker open source, as there is still a lot of interest in the project, and I simply don't have time to work on it these days. 

