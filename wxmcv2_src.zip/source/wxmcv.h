///////////////////////////////////////////////////////////////////////////////
//
// wxmcv.h
//
// Purpose:   Declarations for wxWindows user interface of WX Motion Capture
//            Viewer 2.
//            Classes: MyApp, MyFrame, MySplitter, AboutDialog
//
// Created:   Jaroslav Semancik, 21/10/2003
//
///////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////
//
// class MyApp
//
// Main application class executed by wxWindows. 
//
///////////////////////////////////////////////////////////////////////////////

class MyApp : public wxApp
{
public:
    virtual bool OnInit();
};



///////////////////////////////////////////////////////////////////////////////
//
// class MyFrame
//
// Class for main frame (window) of the application. It contains all controls
// (e.g. menu, toolbar, statusbar) except the OpenGL canvas. OpenGL canvas is
// a global instance to be accesible by all classes. Most of the user
// interface funcionality is provided by MyFrame methods.
//
///////////////////////////////////////////////////////////////////////////////

class MySplitter;   // forward reference for use in MyFrame

class MyFrame : public wxFrame
{
public:

    bool cycle_anim;    // cycle animations?
    bool fwd_playing;   // forward or backward playing
    double time;        // current time
    double frametime;   // time difference between two succesive frames

    MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size);

    // timer callback for animation exporting
    bool ExportFrame(wxCommandEvent& event);

    // event handlers
    void OnOpen(wxCommandEvent& event);
    void OnClose(wxCommandEvent& event);
    void OnQuit(wxCommandEvent& event);
    void OnBack(wxCommandEvent& event);
    void OnBackOne(wxCommandEvent& event);
    void OnPause(wxCommandEvent& event);
    void OnFwd(wxCommandEvent& event);
    void OnFwdOne(wxCommandEvent& event);
    void OnResetTime(wxCommandEvent& event);
    void OnResetView(wxCommandEvent& event);
    void OnToggleCycle(wxCommandEvent& event);
    void OnToggleSolid(wxCommandEvent& event);
    void OnToggleShowFiles(wxCommandEvent& event);
    void OnToggleShotCheckbox(wxCommandEvent& event);
    void OnToggleToolbar(wxCommandEvent& event);
    void OnToggleStatusbar(wxCommandEvent& event);
    void OnExport(wxCommandEvent& event);
    void OnAbout(wxCommandEvent& event);

private:

    // controls in the frame
    wxMenuBar *m_menuBar;
    wxToolBar *m_toolBar;
    wxStatusBar *m_statusBar;
    MySplitter *m_splitter;
    wxCheckListBox *m_fileList;
    wxTimer *m_timer;

    // attributes for animation export
    string m_export_path;
    string m_inc_name, m_ini_name, m_pov_name;
    double m_max_dur;
    int m_frame_number;

    void build_menu();
    void recreate_toolbar();
    void recreate_statusbar();
    void enable_animation_tools(bool en);
    void stop_animation();
    void show_time();
    void create_directories();
    bool create_inc_file();
    bool create_ini_file();
    string frame_filename(const Shot* shot, int fn);
    void write_frame_header(ofstream& file, const Shot* shot, int fn);

    DECLARE_EVENT_TABLE()
};



///////////////////////////////////////////////////////////////////////////////
//
// class MySplitter
//
// A class for sash vertically splitting main frame to a file list window and
// an OpenGL canvas window. The frame can be unsplit and split again and the
// class MySplitter remembers sash position.
//
///////////////////////////////////////////////////////////////////////////////

class MySplitter : public wxSplitterWindow
{
public:

    MySplitter(wxWindow *parent);
    bool SplitVertically(wxWindow* win1, wxWindow* win2);

    // event handlers
    void OnPositionChanged(wxSplitterEvent& event);

private:

    int m_position;

    DECLARE_EVENT_TABLE()
};



///////////////////////////////////////////////////////////////////////////////
//
// class AboutDialog
//
// A class for the "About application" dialog. Creates an info dialog, sizers
// are used to smartly position the dialog content.
//
///////////////////////////////////////////////////////////////////////////////

class AboutDialog : public wxDialog
{
public:
    AboutDialog(wxWindow *parent);
    virtual ~AboutDialog() { }

private:

};



///////////////////////////////////////////////////////////////////////////
//
// event IDs
//
///////////////////////////////////////////////////////////////////////////

enum
{
    ID_OPEN = wxID_OPEN,
    ID_CLOSE = wxID_CLOSE,
    ID_QUIT = wxID_EXIT,
    ID_ABOUT = wxID_ABOUT,

    ID_BACK,
    ID_BACK_ONE,
    ID_PAUSE,
    ID_FWD_ONE,
    ID_FWD,
    ID_RESET_TIME,
    ID_TOGGLE_CYCLE,
    ID_EXPORT,

    ID_TOGGLE_SOLID,
    ID_RESET_VIEW,
    ID_TOGGLE_SHOWFILES,
    ID_TOGGLE_TOOLBAR,
    ID_TOGGLE_STATUSBAR,

    ID_TOOLBAR,
    ID_FILELIST,

    ID_TIMER_FWD,
    ID_TIMER_BACK,
    ID_TIMER_EXPORTING
};


///////////////////////////////////////////////////////////////////////////
//
// Global variables, to be accessible by all classes.
//
///////////////////////////////////////////////////////////////////////////

extern "C++" MyFrame *mainFrame;

