///////////////////////////////////////////////////////////////////////////////
//
// motion.cpp
//
// Purpose:   Implementation of classes related to motion.
//            Classes: DegreeOfFreedom, Motion.
//
// Created:   Jaroslav Semancik, 8/10/2003
//
///////////////////////////////////////////////////////////////////////////////

// #define DEBUG

#include <string>
#include <sstream>
#include <iostream>
#include <stdexcept>
// #include <vector>

using namespace std;

#include "base.h"
#include "motion.h"


// static class attributes

bool DegreeOfFreedom::wrap = true;


///////////////////////////////////////////////////////////////////////////////
//
// class DegreeOfFreedom - public methods
//
///////////////////////////////////////////////////////////////////////////////

// Creates a DOF with name nam and duration dur from n_samples
// uniformly spread samples stored in an array sample.
// Checks that dur >= 0 and n_samples >= 1, otherwise an invalid_argument
// exception is thrown.

DegreeOfFreedom::DegreeOfFreedom(const string& nam, double dur,
    int n_samples, const double* sample) throw(invalid_argument)
{
#ifdef DEBUG
    cout << "Creating degree-of-freedom " << nam << "...";
#endif

    if (dur < 0 || n_samples < 1)
    {
        stringstream error;
    	error << "Creating \"" << nam
              << "\" DegreeOfFreedom with negative duration or no samples"
              << " (duration = " << dur << ", # of samples = " << n_samples
              << ")";
        throw invalid_argument(error.str());
    }

    name = nam;
    duration = dur;

    build_from_samples(n_samples, sample);
    cached = false;

#ifdef DEBUG
    cout << "OK" << endl;
#endif
}


// Destroys the DOF - frees the memory allocated for the signal
// representation.

DegreeOfFreedom::~DegreeOfFreedom() throw()
{
#ifdef DEBUG
    cout << "Destroying degree-of-freedom " << name << "...";
#endif

    delete[] knot;
    delete[] vertex;

#ifdef DEBUG
    cout << "OK" << endl;
#endif
}


// Evaluates the signal at a given time.
// In case that the time > duration of the DOF:
//     it wraps around (i.e. modulo duration), if wrap state is true or
//     returns the value at time == duration, if wrap state is false.
// Similar behaviour occurs for time < 0.

double DegreeOfFreedom::Evaluate(double time) throw()
{
    if (duration == 0 || n_knots == 1) return vertex[0];

    // adjust the time to interval <0, duration>
    if (time > duration)
    {
        if (wrap)
            time = time - floor(time / duration) * duration;
        else
            time = duration;
    }
    else if (time < 0)
    {
        if (wrap)
            time = time - floor(time / duration) * duration;
        else
            time = 0;
    }

    return evaluate_polygon(time);
}



///////////////////////////////////////////////////////////////////////////////
//
// class DegreeOfFreedom - private methods
//
///////////////////////////////////////////////////////////////////////////////

// Fills the knot and vertex arrays of the signal curve derived from uniform
// samples.
// Current implementation just copies the samples as vertices of a polygon
// and distributes the knots uniformly bewteen 0 and duration.

void DegreeOfFreedom::build_from_samples(int n_samples,
     const double *sample) throw()
{
    n_knots = n_samples;
    knot = new double[n_knots];
    vertex = new double[n_knots];

    double t = 0;
    double dt = (n_knots > 1) ? duration / (n_knots - 1) : 0;

    for (int i = 0; i < n_knots; i++)
    {
        knot[i] = t;
        vertex[i] = sample[i];
        t += dt;
    }
}


// Evaluates a piecewise linear polygon given by arrays of knots and vertices
// for time in interval <0, duration>. The vertices are values of the signal
// in the knots.
// Indices of two vertices used in last evaluation are cached for speedup.
// OPTIMIZATION: Adjacent intervals to the cached one should be checked before
// the binary search.

double DegreeOfFreedom::evaluate_polygon(double time) throw()
{
    // if time is not in the cached interval
    if (!cached || time < knot[cached_i1] || time > knot[cached_i2])
    {
        // do binary search for an interval between two succesive knots
        // containing the time
        cached_i1 = 0;
        cached_i2 = n_knots - 1;
        int i;

        while (cached_i2 - cached_i1 > 1)
        {
        	i = (cached_i1 + cached_i2) / 2;
        	if (time < knot[i]) cached_i2 = i;
        	else cached_i1 = i;
        }
        cached = true;
    }

    // correct interpolation to circular around +-180 degrees
    double v1 = vertex[cached_i1];
    double v2 = vertex[cached_i2];
    if (fabs(v1 - v2) > 180)
    {
    	if (v1 < 0) v1 += 360;
    	if (v2 < 0) v2 += 360;
    }

    return v1 + (v2 - v1)
        * (time - knot[cached_i1]) / (knot[cached_i2] - knot[cached_i1]);
}



///////////////////////////////////////////////////////////////////////////////
//
// class Motion - public methods
//
///////////////////////////////////////////////////////////////////////////////

// Creates a motion with name nam, duration dur, number nd of
// degrees-of-freedom and array of DOFs in d.

Motion::Motion(const string& nam, double dur, int nd, DegreeOfFreedom** d)
{
#ifdef DEBUG
    cout << "Creating motion " << nam << "...";
#endif

    name = nam;
    duration = dur;
    n_dofs = nd;
    dof = d;

#ifdef DEBUG
    cout << "OK" << endl;
#endif
}


// Desctructor - destroys all degrees-of-freedom in the motion first.

Motion::~Motion()
{
#ifdef DEBUG
    cout << "Destroying motion " << name << "...";
#endif

    delete[] dof;

#ifdef DEBUG
    cout << "OK" << endl;
#endif    
}



///////////////////////////////////////////////////////////////////////////////
//
// global variables related to motion
//
///////////////////////////////////////////////////////////////////////////////
 

// array of all motions

// vector<Motion*> motions;

