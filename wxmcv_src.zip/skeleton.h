///////////////////////////////////////////////////////////////////////////
//
// skeleton.h
//
// Purpose:   Structure definition of a skeleton (or articulated figure)
//
// Created:   Jaroslav Semancik, 25/06/2003
//
///////////////////////////////////////////////////////////////////////////


#ifndef SKELETON_H
#define SKELETON_H


// bone flags

#define END_SITE   1


class Bone
{
private:
	int id;
	string name;
	unsigned long flags;

    // transformation
	Vector offset;
    Vector rotation;

    // hierarchy
	Bone *parent;
	Bone *child;
	Bone *sibling;

    // automatic id assigning
    static int next_id;

public:
    Bone(const string& nam, const Vector ofs, const unsigned long flgs = 0);
    ~Bone();
    string GetName();
    Vector* GetOffsetPtr();
    Vector* GetRotationPtr();
    void AddChild(Bone *ch);
    void Draw();
    void Export(ofstream& file);
};


class Skeleton
{
private:
    Bone *root;

    friend class SkeletonQueue;
    Skeleton *next;

    /// skeleton attributes (color, etc.)

public:
    Skeleton(Bone *r) { root = r; }
    ~Skeleton() { delete root; }
    void Draw() { root->Draw(); };
    void Export(ofstream& file) { root->Export(file); };
};


class SkeletonQueue
{
private:
    Skeleton *head;
    Skeleton *current;

public:
    SkeletonQueue() { head = NULL; }
    ~SkeletonQueue();
    void AddSkeleton(Bone *root);
    Skeleton* FirstSkeleton();
    Skeleton* NextSkeleton();
    void Draw();
    void Export(ofstream& file);
};


extern "C++" SkeletonQueue *skeletons;

#endif

