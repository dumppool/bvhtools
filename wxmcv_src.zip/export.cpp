///////////////////////////////////////////////////////////////////////////
//
// export.cpp
//
// Purpose:   Implementation of main frame MyFrame methods related to recording
//            and exporting of animation.
//
// Created:   Jaroslav Semancik, 08/07/2003
//
///////////////////////////////////////////////////////////////////////////

#include <wx/wx.h>
#include <wx/glcanvas.h>
#include <wx/image.h>

#include <math.h>
#include <io.h>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>
#include <stdexcept>

using namespace std;

#include "base.h"
#include "vector.h"
#include "skeleton.h"
#include "motion.h"
#include "bvh.h"
#include "ogl.h"
#include "wxmcv.h"


/////////////////////////////////////////////////////////////////////////////
// MyFrame - public methods related to export
/////////////////////////////////////////////////////////////////////////////

void MyFrame::OnRecord(wxCommandEvent& event)
{
    // in case of recording first time, set path to opened file path
    if (m_recpath == "") m_recpath = m_bvhpath;

    // choose output directory by a common dialog
    wxDirDialog *dlg = new wxDirDialog(this, _T("Choose output directory"),
        m_recpath.c_str(), wxDD_NEW_DIR_BUTTON);

    if (dlg->ShowModal() != wxID_OK) return;

    m_recpath = dlg->GetPath();
    dlg->Destroy();

    // set name by removing extension from the input file name
    m_name = m_bvhname;
    strip_extension(m_name, ".bvh");

    // set window device context of the canvas
    m_canvasDC = new wxWindowDC(glCanvas);

    // create bitmap and link to its memory device context to copy the canvas
    m_bitmap_size = glCanvas->GetClientSize();
    m_bitmap.Create(m_bitmap_size.x, m_bitmap_size.y, -1);
    m_memoryDC.SelectObject(m_bitmap);

    SetStatusText(_T("Recording animation..."));

    // save first frame
    motion->FirstFrame();
    glCanvas->DrawSkeletons();
    if (!SaveFrame(event)) return;

    // set timer to save all remaining frames
    m_fwd = true;
    if (m_cycle) OnToggleCycle(event);
    m_timer->SetOwner(mainFrame, ID_TIMER_RECORDING);
    m_timer->Start(int(motion->frame_time * 1000));  // time interval in miliseconds
}


// this function is periodically called by timer when recording animation,
// it saves current glCanvas content to a .png file and goes to next frame
// returns false and stops animation if file creation failed

bool MyFrame::SaveFrame(wxCommandEvent& WXUNUSED(event))
{
    // create file name for current frame
    string filename = frame_filename(m_recpath, m_name, ".png");

    // copy from canvas to bitmap in memory DC, convert to image and save
    // to a PNG file
    m_memoryDC.Blit(wxPoint(0, 0), m_bitmap_size, m_canvasDC, wxPoint(2, 2));  // 2 is the border thickness
    m_image = m_bitmap.ConvertToImage();

    if (!m_image.SaveFile(filename.c_str(), wxBITMAP_TYPE_PNG))
    {
        StopAnimation();
        error << "Unable to create file " << filename << ". Disk full or write protection?";
        Message(error.str());
        return false;
    }

    // go to next frame
    motion->NextFrame();
    glCanvas->DrawSkeletons();
    return true;
}


void MyFrame::OnExport(wxCommandEvent& event)
{
    // in case of exporting first time, set path to opened file path
    if (m_exppath == "") m_exppath = m_bvhpath;

    // choose output directory by a common dialog
    wxDirDialog *dlg = new wxDirDialog(this, _T("Choose output directory"),
        m_exppath.c_str(), wxDD_NEW_DIR_BUTTON);

    if (dlg->ShowModal() != wxID_OK) return;

    m_exppath = dlg->GetPath();
    dlg->Destroy();

    // set name by removing extension from the input file name
    m_name = m_bvhname;
    strip_extension(m_name, ".bvh");

    SetStatusText(_T("Exporting animation..."));

    // create main .inc file with blob which includes individual frames
    if (!create_blob_file()) return;

    // create POV-Ray .ini file with animation settings
    if (!create_ini_file()) return;

    // create ./out directory for POV-Ray output images
    mkdir((m_exppath + "/out").c_str());

    // export first frame
    motion->FirstFrame();
    glCanvas->DrawSkeletons();  // just for visual control of the progress
    if (!ExportFrame(event)) return;

    // set timer to save all remaining frames
    m_fwd = true;
    if (m_cycle) OnToggleCycle(event);
    m_timer->SetOwner(mainFrame, ID_TIMER_EXPORTING);
    m_timer->Start(int(motion->frame_time * 1000));  // time interval in miliseconds
}


// this function is periodically called by timer when exporting animation,
// it stores current skeletons pose as a set of POV-Ray blob components
// to an .inc file and goes to next frame
// returns false and stops animation if file creation failed

bool MyFrame::ExportFrame(wxCommandEvent& WXUNUSED(event))
{
    // create file name for current frame
    string filename = frame_filename(m_exppath, m_name, ".inc");
    ofstream file;

    // open file for write
    file.open(filename.c_str());
    if (!file)
    {
        StopAnimation();
        error << "Unable to create file " << filename << ". Disk full or write protection?";
        Message(error.str());
        return false;
    }

    // write header comments
    write_frame_header(file);

    // write segments of all skekeltons
    skeletons->Export(file);

    file.close();

    // go to next frame
    motion->NextFrame();
    glCanvas->DrawSkeletons();  // just for visual control of the progress
    return true;
}



/////////////////////////////////////////////////////////////////////////////
// MyFrame - public methods related to export
/////////////////////////////////////////////////////////////////////////////

// strip file extension ext (e.g. ".bvh") from string name

void MyFrame::strip_extension(string& name, const string& ext)
{
    unsigned int n = name.find(ext, 0);
    if (n != string::npos) name.erase(n);
}


// create main file with blob to be included from POV-Ray scene
// this file includes particular .inc file with just rendered frame number
// returns false if file creation failed

bool MyFrame::create_blob_file()
{
    // create file name
    stringstream pathname;
    pathname << m_exppath << '/' << m_name << ".inc";

    string filename = pathname.str();
    ofstream file;

    // open file for write
    file.open(filename.c_str());
    if (!file)
    {
        error << "Unable to create file " << filename << ". Disk full or write protection?";
        Message(error.str());
        return false;
    }

    // write initial comments
    file << "//" << endl
         << "// " << m_name << ".inc - main include file with skeletons as a POV-Ray blob" << endl
         << "//" << endl
         << "// Use in your scene by: " << endl
         << "//" << endl
         << "//     object {" << endl
         << "//         #include \"" << m_name << ".inc\"" << endl
         << "//         texture { SET_YOUR_MATERIAL_HERE }" << endl
         << "//     }" << endl
         << "//" << endl
         << "// and set animation .ini file for POV-Ray rendering to " << m_name << ".ini" << endl
         << "//" << endl
         << "// Generated by Motion Capture Viewer" << endl
         << "//" << endl
         << "//////////////////////////////////////////////////////////////////////" << endl
         << endl;

    // determine width of frame number
    int w = (int)log10((float)motion->n_frames) + 1;

    // write blob
    file << "#declare th = 2;      // thickness of bones" << endl
         << "#declare jnt = -0.9;  // blob adjustment in joints" << endl
         << endl
         << "blob {" << endl
         << "    threshold .5" << endl
         << "    #declare incname = " << "concat(\"" << m_name << "\", str(frame_number, "
             << -w << ", 0), \".inc\")" << endl
         << "    #include incname" << endl
         << "}" << endl;

    file.close();
    return true;
}


// create a POV-Ray .ini file with animation settings
// returns false if file creation failed

bool MyFrame::create_ini_file()
{
    // create file name
    stringstream pathname;
    pathname << m_exppath << '/' << m_name << ".ini";

    string filename = pathname.str();
    ofstream file;

    // open file for write
    file.open(filename.c_str());
    if (!file)
    {
        error << "Unable to create file " << filename << ". Disk full or write protection?";
        Message(error.str());
        return false;
    }

    // write initial comments
    file << ";" << endl
         << "; " << m_name << ".ini - POV-Ray animation settings" << endl
         << ";" << endl
         << "; For settings meaning see POV-Ray documention" << endl
         << ";" << endl
         << "; Generated by Motion Capture Viewer" << endl
         << ";" << endl
         << ";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;" << endl
         << endl;

    // write animation settings
    file << "Input_File_Name=" << m_name << ".pov" << endl
         << "Output_File_Name=.\\out\\" << endl
         << endl
         << endl
         << "; animation settings" << endl
         << endl
         << "Initial_Frame=" << 0 << endl
         << "Final_Frame=" << motion->n_frames - 1 << endl
         << "Cyclic_Animation=off" << endl
         << endl
         << endl
         << "; uncomment and set the following to render a particular frame(s)" << endl
         << endl
         << "; Subset_Start_Frame=" << endl
         << "; Subset_End_Frame=" << endl
         << endl
         << endl
         << "; output size" << endl
         << endl
         << "Width=320" << endl
         << "Height=240" << endl
         << endl
         << endl
         << ";antialiasing" << endl
         << endl
         << "Antialias=on         ; turn off for test renderings" << endl
         << "Sampling_Method=2" << endl
         << "Antialias_Depth=3" << endl
         << "Jitter=off" << endl;

    file.close();
    return true;
}


// returns full name with path and extension of a file for current frame number

string MyFrame::frame_filename(const string& path, const string& name, const string& ext)
{
    stringstream pathname;

    int n = motion->GetFrame();
    int w = (int)log10((float)motion->n_frames) + 1;
    pathname << path << '/' << name << setw(w) << setfill('0') << n << ext;

    return pathname.str();
}


// write comments on the beginning of each frame .inc file

void MyFrame::write_frame_header(ofstream& file)
{
    file << "//" << endl
         << "// " << m_name << ": frame " << motion->GetFrame()
            << ",  blob components included from " << m_name << ".inc" << endl
         << "//" << endl
         << "// Generated by Motion Capture Viewer" << endl
         << "//" << endl
         << "//////////////////////////////////////////////////////////////////////" << endl
         << endl;
}

