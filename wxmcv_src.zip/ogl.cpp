///////////////////////////////////////////////////////////////////////////
//
// ogl.cpp
//
// Purpose:   Implementation of canvas for drawing by OpenGL and methods
//            for visualization of skeletons.
//
// Created:   Jaroslav Semancik, 01/07/2003
//
///////////////////////////////////////////////////////////////////////////

#include <wx/wx.h>
#include <wx/glcanvas.h>
#include <wx/image.h>

#ifdef __WXMAC__
#  ifdef __DARWIN__
#    include <OpenGL/glu.h>
#  else
#    include <glu.h>
#  endif
#else
#  include <gl/glu.h>
#endif

#include <fstream>
#include <string>
#include <sstream>
#include <stdexcept>
#include <math.h>

using namespace std;

#include "base.h"
#include "vector.h"
#include "skeleton.h"
#include "wxmcv.h"
#include "ogl.h"


/////////////////////////////////////////////////////////////////////////////
// MyGLCanvas event table
/////////////////////////////////////////////////////////////////////////////

BEGIN_EVENT_TABLE(MyGLCanvas, wxGLCanvas)
    EVT_SIZE(MyGLCanvas::OnSize)
    EVT_PAINT(MyGLCanvas::OnPaint)
    EVT_MOUSE_EVENTS(MyGLCanvas::OnMouse)
END_EVENT_TABLE()


/////////////////////////////////////////////////////////////////////////////
// MyGLCanvas - public methods
/////////////////////////////////////////////////////////////////////////////

// constructor - initialize attributes (projection, scene transformation and
// display lists)

MyGLCanvas::MyGLCanvas(wxWindow *parent, wxWindowID id,
    const wxPoint& pos, const wxSize& size, long style, const wxString& name)
    : wxGLCanvas(parent, id, pos, size, style, name)
{
    m_solid_rendering = false;

    // set projection parameters
    m_fovy = 45;
    m_near = 1;
    m_far = 1000;

    SetInitialView();

    // allocate display list id's
    m_grid_dl = glGenLists(1);
    m_skeletons_dl = glGenLists(1);
}


// destructor

MyGLCanvas::~MyGLCanvas()
{
}


// initialize OpenGL state - various rendering settings
// prepare static display lists

void MyGLCanvas::InitGL(void)
{
    // two white lights
    GLfloat light_Ka[] = { 0.0, 0.0, 0.0, 1.0 };
    GLfloat light_Kd[] = { 0.8, 0.8, 0.8, 0.8 };
    GLfloat light_Ks[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat light0_pos[] = { -50.0, 50.0, 30.0, 0.0 };
    GLfloat light1_pos[] = {  50.0, 50.0, -10.0, 0.0 };

    // common properties of materials
    GLfloat mat_Ks[] = { 0.5, 0.5, 0.5, 1.0 };
    GLfloat mat_Ke[] = { 0.0, 0.0, 0.0, 0.0 };
    GLfloat mat_Sh[] = { 90.0 };

    // lights
    glLightfv(GL_LIGHT0, GL_AMBIENT,  light_Ka);
    glLightfv(GL_LIGHT0, GL_DIFFUSE,  light_Kd);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_Ks);
    glLightfv(GL_LIGHT0, GL_POSITION, light0_pos);

    glLightfv(GL_LIGHT1, GL_AMBIENT,  light_Ka);
    glLightfv(GL_LIGHT1, GL_DIFFUSE,  light_Kd);
    glLightfv(GL_LIGHT1, GL_SPECULAR, light_Ks);
    glLightfv(GL_LIGHT1, GL_POSITION, light1_pos);

    glEnable(GL_LIGHT0);
    glEnable(GL_LIGHT1);
    glEnable(GL_NORMALIZE);

    // material
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_Ks);
    glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, mat_Ke);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_Sh);

    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
    glEnable(GL_COLOR_MATERIAL);

    glClearColor(0.0, 0.2, 0.1, 0.0);
    glClearDepth(1.0);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glShadeModel(GL_SMOOTH);

    // prepare static display lists
    draw_grid();
}


// set initial view to the scene

void MyGLCanvas::SetInitialView()
{
    // set initial rotation of the scene
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glRotatef(40.0, 0.0, 1.0, 0.0);
    glGetFloatv(GL_MODELVIEW_MATRIX, m_rotation.c);

    // set initial translation of the scene
    m_translation = Vector(0, -50, -250);
}


void MyGLCanvas::OnPaint(wxPaintEvent& event)
{
    // must always be here
    wxPaintDC dc(this);

#ifndef __WXMOTIF__
    if (!GetContext()) return;
#endif

    SetCurrent();

    // scene transformation
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glTranslatef(m_translation.x, m_translation.y, m_translation.z);
    glMultMatrixf(m_rotation.c);

    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

    // draw scene
    glDisable(GL_LIGHTING);
    glCallList(m_grid_dl);          // basic grid

    if (m_solid_rendering) glEnable(GL_LIGHTING);
    glCallList(m_skeletons_dl);     // skeletons

    // flush and swap buffers
    glFlush();
    SwapBuffers();
}


// on resize reset viewport and projection

void MyGLCanvas::OnSize(wxSizeEvent& event)
{
    // this is also necessary to update the context on some platforms
    wxGLCanvas::OnSize(event);

    int w, h;
    GetClientSize(&w, &h);
#ifndef __WXMOTIF__
    if (GetContext())
#endif
    {
        SetCurrent();
        glViewport(0, 0, w, h);

        // reset perspective projection
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective(m_fovy, (float)w / h, m_near, m_far);
    }
}


void MyGLCanvas::OnMouse(wxMouseEvent& event)
{
    int w, h;
    GetClientSize(&w, &h);

    if (event.Dragging())
    {
    	wxPoint mouse = event.GetPosition();

    	if (event.LeftIsDown() && event.RightIsDown())
    	{
    		// move
            float k = 2.0 * tan(D2R(m_fovy / 2)) / h;
    		m_translation.x -= (mouse.x - m_last_mouse.x) * m_translation.z * k;
    		m_translation.y += (mouse.y - m_last_mouse.y) * m_translation.z * k;
    	}

    	else if (event.LeftIsDown())
    	{
    		// rotate
    		float kx = 100.0 / h;
    		float ky = 100.0 / w;
            float rx = (mouse.y - m_last_mouse.y) * ky;
            float ry = (mouse.x - m_last_mouse.x) * kx;

            // add rotation to rotation matrix of the scene
            glMatrixMode(GL_MODELVIEW);
    		glLoadIdentity();
    		glRotatef(rx, 1.0, 0.0, 0.0);
    		glRotatef(ry, 0.0, 1.0, 0.0);
            glMultMatrixf(m_rotation.c);
            glGetFloatv(GL_MODELVIEW_MATRIX, m_rotation.c);
    	}

        else if (event.RightIsDown())
        {
        	// scale
            float k = 3.0 / h;
        	m_translation.z += (float)(mouse.y - m_last_mouse.y)
                                * m_translation.z * k;
        }

        // orientation has changed, redraw scene
        Refresh(false);
    }

    m_last_mouse = event.GetPosition();
}


// draw point p by color (r,g,b,a)
// p is rendered as a point or small a sphere according to m_solid_rendering

#define POINT_SIZE  1.0

void MyGLCanvas::RenderPoint(const Vector& p,
        float r, float g, float b, float a)
{

    glColor4f(r, g, b, a);

    if (m_solid_rendering)
    {
        glPushMatrix();
        glTranslatef(p.x, p.y, p.z);
        GLUquadricObj *point = gluNewQuadric();
            gluSphere(point, POINT_SIZE, 10, 10);
        gluDeleteQuadric(point);
        glPopMatrix();
    }

    else
    {
        glBegin(GL_POINTS);
            glVertex3fv(p.c);
        glEnd();
    }
}


// draw line between p1 and p2 by color (r,g,b,a)
// the line is rendered as a line or a thin cylinder according to m_solid_rendering

#define LINE_THICKNESS  0.5

void MyGLCanvas::RenderLine(const Vector& p1, const Vector& p2,
        float r, float g, float b, float a)
{
    float d, x_rot, y_rot;

    glColor4f(r, g, b, a);

    if (m_solid_rendering)
    {
        // determine line length and rotation angles needed to align
        // positive Z-axis onto vector direction
        Vector v = p2 - p1;
        v.polar(d, x_rot, y_rot);

        // transform (converts radians to degrees first)
        glPushMatrix();
        glTranslatef(p1.x, p1.y, p1.z);
        glRotatef(R2D(y_rot), 0.0, 1.0, 0.0);
        glRotatef(R2D(x_rot), 1.0, 0.0, 0.0);
        GLUquadricObj *line = gluNewQuadric();
            gluCylinder(line, LINE_THICKNESS, LINE_THICKNESS, d, 10, 1);
        gluDeleteQuadric(line);
        glPopMatrix();
    }

    else
    {
        glBegin(GL_LINES);
            glVertex3fv(p1.c);
            glVertex3fv(p2.c);
        glEnd();
    }
}


// draw all skeletons in current pose to display list m_skeletons_dl

void MyGLCanvas::DrawSkeletons()
{
    glNewList(m_skeletons_dl, GL_COMPILE);
        if (skeletons) skeletons->Draw();
    glEndList();
   	Refresh(false);
}


/////////////////////////////////////////////////////////////////////////////
// MyGLCanvas - private methods
/////////////////////////////////////////////////////////////////////////////

// draw basic grid in XZ plane around origin to display list

void MyGLCanvas::draw_grid()
{
    glNewList(m_grid_dl, GL_COMPILE);

    glColor3f(0.5, 0.5, 0.5);
    glBegin(GL_LINES);
    for (int i = -100; i <= 100; i += 20)
    {
        glVertex3f(i, 0, -100);
        glVertex3f(i, 0, 100);
        glVertex3f(-100, 0, i);
        glVertex3f(100, 0, i);
    }
    glEnd();

    glEndList();
}


// global drawing canvas

MyGLCanvas *glCanvas = NULL;

