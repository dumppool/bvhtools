///////////////////////////////////////////////////////////////////////////
//
// motion.h
//
// Purpose:   Declaration of classes for motion and its channels
//
// Created:   Jaroslav Semancik, 28/06/2003
//
///////////////////////////////////////////////////////////////////////////


#ifndef MOTION_H
#define MOTION_H

class Channel
{
private:
    string name;
    float *target;
    float *data;
    int size;

    friend class Motion;
    Channel *next;

public:
    Channel(const string& nam, float *trg) throw();
    ~Channel() throw();
    void SetSize(int s);
    void Channel::SetData(int pos, float f) throw(out_of_range);
    float Channel::GetData(int pos) throw(out_of_range);
};


class Motion
{
private:
    Channel *head, *last;
    Channel *current;
    int frame;              // current frame

public:
    int n_channels;
    int n_frames;
    float frame_time;

    Motion();
    ~Motion();
    void AddChannel(const string& nam, float *trg);
    Channel* FirstChannel();
    Channel* NextChannel();
    int GetFrame() throw();
    void SetFrame(int n) throw(out_of_range);
    void FirstFrame();
    void NextFrame();
    void PreviousFrame();
};


extern "C++" Motion *motion;

#endif

