///////////////////////////////////////////////////////////////////////////
//
// bvh.cpp
//
// Purpose:   BVH file format parser - implementation of the class
//
// Created:   Jaroslav Semancik, 26/06/2003
//
///////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <stdexcept>

using namespace std;

#include "base.h"
#include "vector.h"
#include "skeleton.h"
#include "motion.h"
#include "bvh.h"

///////////////////////////////////////////////////////////////////////////
//
// Used BVH file format gramatics:
//
// .bvh        -> [hierarchy] [motion] end-of-file
// hierarchy   -> "HIERARCHY" (root)*
// root        -> "ROOT" name { joint-data }
// joint       -> "JOINT" name { joint-data }
// joint-data  -> offset [channels] (joint/end-site)+
// end-site    -> "End" "Site" { offset }
// offset      -> "OFFSET" float float float
// channels    -> "CHANNELS" int (Xposition/Yposition/Zposition/Xrotation/Yrotation/Zrotation)*
// motion      -> "MOTION" "Frames:" int "Frame" "Time:" float motion-data
// motion-data -> (float)*
//
// where
//
// [item]   means an optional item
// "token"  means token (without quotes) in the input file
// foo/bar  means either foo or bar
// (item)*  means any number (including zero) of items
// (item)+  means at least one item
// {        means { in the input file (as well for } )
//
///////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////
// BVH - public methods
///////////////////////////////////////////////////////////////////////////

// open .bvh file, parse it
// build a skeleton hierarchy and motion table and connect motion data channels to hierarchy
// show message if an error occured
// return whether loading was succesfull

bool BVH::Load() throw()
{
    bool ok = true;

    // open file
    file.open(filename.c_str());
    if (!file)
    {
        error << "Unable to open file " << filename;
        Message(error.str());
        return false;
    }

   	// delete current animation
  	if (motion) delete motion;
   	if (skeletons) delete skeletons;

    skeletons = new SkeletonQueue();
    motion = new Motion();

    // parse
    line = 1;
    try {
        parse_bvh();
    }

    // show message if parse error occured
    catch (parse_error &pe)
    {
        error << "Parse error: " << pe.what() << " at line " << line;
        Message(error.str());
        ok = false;
    }

    // show message if out of range occured
    catch (out_of_range &oor)
    {
        error << "Internal error - out of range: " << oor.what()
              << " at line " << line;
        Message(error.str());
        ok = false;
    }

    // close file
    file.close();
    return ok;
}


///////////////////////////////////////////////////////////////////////////
// BVH - private methods
///////////////////////////////////////////////////////////////////////////

// read one token from file skiping all whitespace (' ','\t','\n')
// "end-of-file" token is returned at the end of file
// valid characters are: +-.0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_:{}
// 1st place only characters: +-{}
// throw parse error exception if an invalid character occurs

void BVH::read_next_token() throw(parse_error)
{
    char c;

    // skip leading whitespace while counting lines
    while (file.get(c) && strchr(" \t\n", c))
        if (c == '\n') line++;

    // test end of file
    if (!file)
    {
        token = "end-of-file";
        return;
    }

    // if an invalid character occured, throw parse error exception about it
    if (!strchr("+-.0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_:{}", c))
    {
        error << "Invalid character " << c << " occured";
        throw parse_error (error.str());
    }

    // read token
    stringstream token_stream;
    token_stream << c;
    while (file.get(c) && strchr(".0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_:", c))
        token_stream << c;

    file.unget();
    token_stream >> token;
}


// test if current token is a specified token

bool BVH::token_is(const string& tok) throw()
{
    return (token == tok);
}


// if current token is the specified one, read next token
// else throw parse error exception about misplaced token

void BVH::take_token(const string& tok) throw(parse_error)
{
    if (token_is(tok)) read_next_token();
    else
    {
        if (tok != "end-of-file") error << "Token \"" << tok << '"';
        else error << "end of file";
        error << " expected, but \"" << token << "\" found instead";

        throw parse_error(error.str());
    }
}


// store current token to a string variable and read next token

void BVH::token_to_string(string& str) throw(parse_error)
{
    str = token;
    read_next_token();
}


// convert current token to float and read next token
// if conversion failed throw parse error exception about it

void BVH::token_to_float(float& num) throw(parse_error)
{
    stringstream s;
    s << token;
    s >> num;

    if (!s)
    {
        error << "\"" << token << "\" cannot be converted to float";
        throw parse_error(error.str());
    }

    read_next_token();
}


// convert current token to int and read next token
// if conversion failed throw parse error exception about it

void BVH::token_to_int(int& num) throw(parse_error)
{
    stringstream s;
    s << token;
    s >> num;

    if (!s)
    {
        error << "\"" << token << "\" cannot be converted to int";
        throw parse_error(error.str());
    }

    read_next_token();
}



// .bvh -> [hierarchy] [motion] end-of-file

void BVH::parse_bvh() throw(parse_error, out_of_range)
{
    // read first token
    read_next_token();

    if (token_is("HIERARCHY")) parse_hierarchy();

    if (token_is("MOTION")) parse_motion();

    take_token("end-of-file");
}


// hierarchy -> "HIERARCHY" (root)*

void BVH::parse_hierarchy() throw(parse_error)
{
    take_token("HIERARCHY");

    while (token_is("ROOT")) parse_root();
}


// root -> "ROOT" name { joint-data }

void BVH::parse_root() throw(parse_error)
{
    take_token("ROOT");

    token_to_string(bone_name);

    take_token("{");

    parse_joint_data(NULL);

    take_token("}");
}


// joint -> "JOINT" name { joint-data }

void BVH::parse_joint(Bone *parent) throw(parse_error)
{
    take_token("JOINT");

    token_to_string(bone_name);

    take_token("{");

    parse_joint_data(parent);

    take_token("}");
}


// joint-data -> offset [channels] (joint/end-site)+

void BVH::parse_joint_data(Bone *parent) throw(parse_error)
{
    parse_offset();

#ifdef DDD
    cout << "Creating bone " << bone_name << "...";
#endif

    // create bone
    Bone *bone = new Bone(bone_name, bone_offset);

    if (parent)
        parent->AddChild(bone);
    else
        // root of a new hierarchy
    	// create a new skeleton and add it to skeletons in the scene
    	skeletons->AddSkeleton(bone);

#ifdef DDD
    cout << "OK" << endl;
#endif    

    if (token_is("CHANNELS")) parse_channels(bone);

    if (token_is("JOINT")) parse_joint(bone);
    else if (token_is("End")) parse_end_site(bone);
    else
    {
    	error << "\"JOINT\" or \"End Site\" expected, but \"" << token << "\" found instead";
    	throw parse_error(error.str());
    }

    while (token_is("JOINT") || token_is("End"))
    {
        if (token_is("JOINT")) parse_joint(bone);
        else parse_end_site(bone);
    }
}


// end-site -> "End" "Site" { offset }

void BVH::parse_end_site(Bone *parent) throw(parse_error)
{
    take_token("End");
    take_token("Site");

    take_token("{");

    parse_offset();

#ifdef DDD
    cout << "Creating end-site " << bone_name << "...";
#endif    

    // create a special end-site bone with flag END_SITE
    Bone *bone = new Bone(bone_name, bone_offset, END_SITE);

    if (parent)
        parent->AddChild(bone);
    else
    {
    	// his should not occur, but...
    	skeletons->AddSkeleton(bone);
        Message("End-site without parent appeared.");
    }

#ifdef DDD
    cout << "OK" << endl;
#endif

    take_token("}");
}


// offset -> "OFFSET" float float float

void BVH::parse_offset() throw(parse_error)
{
    take_token("OFFSET");

    token_to_float(bone_offset.x);
    token_to_float(bone_offset.y);
    token_to_float(bone_offset.z);
}


// channels -> "CHANNELS" int (Xposition/Yposition/Zposition/Xrotation/Yrotation/Zrotation)*

void BVH::parse_channels(Bone *bone) throw(parse_error)
{
    int declared_channels, listed_channels = 0;

    take_token("CHANNELS");

    token_to_int(declared_channels);

    while (listed_channels < declared_channels)
    {
        if (token_is("Xposition"))
        {
            motion->AddChannel(bone->GetName() + ".Xposition", &(bone->GetOffsetPtr()->x));
            listed_channels++;
            read_next_token();
        }

        else if (token_is("Yposition"))
        {
            motion->AddChannel(bone->GetName() + ".Yposition", &(bone->GetOffsetPtr()->y));
            listed_channels++;
            read_next_token();
        }

        else if (token_is("Zposition"))
        {
            motion->AddChannel(bone->GetName() + ".Zposition", &(bone->GetOffsetPtr()->z));
            listed_channels++;
            read_next_token();
        }

        else if (token_is("Xrotation"))
        {
            motion->AddChannel(bone->GetName() + ".Xrotation", &(bone->GetRotationPtr()->x));
            listed_channels++;
            read_next_token();
        }

        else if (token_is("Yrotation"))
        {
            motion->AddChannel(bone->GetName() + ".Yrotation", &(bone->GetRotationPtr()->y));
            listed_channels++;
            read_next_token();
        }

        else if (token_is("Zrotation"))
        {
            motion->AddChannel(bone->GetName() + ".Zrotation", &(bone->GetRotationPtr()->z));
            listed_channels++;
            read_next_token();
        }

        // if any other token was found stop reading channels
        else break;
    }

    // check number of channels
    if (listed_channels != declared_channels)
        throw parse_error("Incorrect number of listed channels");
}


// motion -> "MOTION" "Frames:" int "Frame" "Time:" float motion-data

void BVH::parse_motion() throw(parse_error, out_of_range)
{
    take_token("MOTION");

    take_token("Frames:");

    token_to_int(motion->n_frames);

    take_token("Frame");
    take_token("Time:");

    token_to_float(motion->frame_time);

    parse_motion_data();
}


// motion-data -> (float)*

void BVH::parse_motion_data() throw(parse_error, out_of_range)
{
    Channel *chan;
    float f;

    // set size of all channels to number of frames
    chan = motion->FirstChannel();
    while (chan)
    {
    	chan->SetSize(motion->n_frames);
    	chan = motion->NextChannel();
    }

#ifdef DDD
    cout << endl << "Reading motion data...";
#endif

    for (int i = 0; i < motion->n_frames; i++)
    {
    	chan = motion->FirstChannel();

        while (chan)
        {
            token_to_float(f);
            chan->SetData(i, f);
            chan = motion->NextChannel();
        }
    }

#ifdef DDD
    cout << "OK" << endl;
#endif
}

