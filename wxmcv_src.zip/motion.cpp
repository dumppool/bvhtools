///////////////////////////////////////////////////////////////////////////
//
// motion.cpp
//
// Purpose:   Motion channels handling - implementation of classes
//
// Created:   Jaroslav Semancik, 28/06/2003
//
///////////////////////////////////////////////////////////////////////////

#include <wx/wx.h>
#include <wx/image.h>

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <stdexcept>

using namespace std;

#include "base.h"
#include "wxmcv.h"
#include "motion.h"


///////////////////////////////////////////////////////////////////////////
// Channel - public methods
///////////////////////////////////////////////////////////////////////////

// constructor - create an empty channel with name nam
// targeting a float variable trg

Channel::Channel(const string& nam, float *trg) throw()
{
    name = nam;
    target = trg;
    data = NULL;
    size = 0;
    next = NULL;

#ifdef DDD
    cout << "\tChannel " << nam << " created" << endl;
#endif    
}


// destructor - delete channel data if any

Channel::~Channel() throw()
{
    if (data) delete[] data;
}


// set number of channel data, delete current channel data before

void Channel::SetSize(int s)
{
    // delete current channel data
    if (data) delete[] data;
    data = NULL;
    size = 0;

    if (s <= 0) return;

    data = new float[s];
    size = s;
}


// set channel data at position pos to value f
// throw out_of_range exception if pos is out of size of the channel

void Channel::SetData(int pos, float f) throw(out_of_range)
{
    if (pos >= 0 && pos < size)
        data[pos] = f;
    else
    {
    	error << "setting " << pos << ". item in channel " << name
              << " of size " << size;
        throw out_of_range(error.str());
    }
}


// get channel data at position pos
// throw out_of_range exception if pos is out of size of the channel

float Channel::GetData(int pos) throw(out_of_range)
{
    if (pos >= 0 && pos < size)
        return data[pos];
    else
    {
    	error << "getting " << pos << ". item from channel " << name
              << " of size " << size;
        throw out_of_range(error.str());
    }
}


///////////////////////////////////////////////////////////////////////////
// Motion - public methods
///////////////////////////////////////////////////////////////////////////

// constructor - create empty queue of channels

Motion::Motion()
{
    head = last = NULL;
    current = NULL;
    n_channels = n_frames = 0;
    frame_time = 0;
    frame = -1;
}


// destructor - delete all channels

Motion::~Motion()
{
    Channel *ch;

    while (head)
    {
    	ch = head->next;
    	delete head;
    	head = ch;
    }
}


// create a channel with name nam and target trg
// add it at the end of queue to preserve channels order

void Motion::AddChannel(const string& nam, float *trg)
{
    Channel *chan = new Channel(nam, trg);

    if (!head)
    	head = chan;
    else
        last->next = chan;

    last = chan;

    n_channels++;
}


// set current channel to first channel and return its pointer

Channel* Motion::FirstChannel()
{
    current = head;
    return current;
}


// set current channel to next channel and return its pointer

Channel* Motion::NextChannel()
{
    if (current)
        current = current->next;
    return current;
}


// return number of current frame

int Motion::GetFrame() throw()
{
    return frame;
}


// set frame to n
// set skeletons to a pose given for n-th frame (i.e. write n-th data
// of each channel to its target)
// if n is out of frames range (and n_frames > 0) throw out-of-error
// exception about it

void Motion::SetFrame(int n) throw(out_of_range)
{
    if (n_frames == 0) return;

    // check if n is range of frames
    if (n >= 0 && n < n_frames)
    	frame = n;
    else
    {
    	error << "setting " << n << ". frame in motion with "
              << n_frames << "frames";
        throw out_of_range(error.str());
    }

    // set targets of all channels to channel n-th data
    // Note: preserves current attribute for FirstChannel() and NextChannel() using
    Channel *ch = head;
    while (ch)
    {
    	*(ch->target) = ch->data[n];
    	ch = ch->next;
    }

    // show frame number in 2-nd field of statusbar
    stringstream s;
    s << "Frame: " << frame + 1 << " / " << n_frames;
    mainFrame->SetStatusText(_T(s.str().c_str()), 1);
}


// set skeletons to first frame pose

void Motion::FirstFrame()
{
    frame = 0;
    SetFrame(frame);
}


// set skeletons to next frame pose
// cycle or stop the animation according to Cycle animation menu setting

void Motion::NextFrame()
{
    frame++;
    if (frame >= n_frames)
    {
        if (mainFrame->m_cycle) frame = 0;
        else
        {
        	frame--;
            mainFrame->StopAnimation();
        }
    }
    SetFrame(frame);
}


// set skeletons to previous frame pose
// cycle or stop the animation according to Cycle animation menu setting

void Motion::PreviousFrame()
{
    frame--;
    if (frame < 0)
    {
        if (mainFrame->m_cycle) frame = n_frames - 1;
        else
        {
        	frame++;
            mainFrame->StopAnimation();
        }
    }
    SetFrame(frame);
}


///////////////////////////////////////////////////////////////////////////
// global variables related to the motion
///////////////////////////////////////////////////////////////////////////

// pointer to a queue of all motion channels

Motion *motion = NULL;

