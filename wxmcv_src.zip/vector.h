///////////////////////////////////////////////////////////////////////////
//
// vector.h
//
// Purpose:   Auxiliary mathematics, vectors, matrices
//
// Created:   Jaroslav Semancik, 01/07/2003
//
///////////////////////////////////////////////////////////////////////////

#ifndef VECTOR_H
#define VECTOR_H

struct Vector
{
    union
    {
        struct { float x, y, z; };
        float c[3];
    };

    Vector(float xx = 0.0, float yy = 0.0, float zz = 0.0)
        : x(xx), y(yy), z(zz) {}
    ~Vector() {};

    Vector& operator += (const Vector& v)                   // V += V
        { x += v.x; y += v.y; z += v.z; return *this; }

    Vector& operator -= (const Vector& v)                   // V -= V
        { x -= v.x; y -= v.y; z -= v.z; return *this; }

    Vector& operator *= (float k)                           // V *= k
        { x *= k; y *= k; z *= k; return *this; }

    float length() const                                    // d = V.length()
        { return sqrt(x * x + y * y + z * z); }

    void normalize();                                       // V.normalize()

    // V.polar(d, x_rot, y_rot)
    void polar(float& d, float& x_rot, float& y_rot) const;
};

// operations on vectors

Vector operator + (const Vector& v1, const Vector& v2);
Vector operator - (const Vector& v1, const Vector& v2);
Vector operator - (const Vector& v);
Vector operator * (double k, const Vector& v);
bool operator == (const Vector& v1, const Vector& v2);
float dot(const Vector& v1, const Vector& v2);
Vector cross(const Vector& v1, const Vector& v2);
float angle(const Vector& v1, const Vector& v2);
ostream& operator << (ostream& os, const Vector& v);


// OpenGL compatible matrix type

struct Matrix
{
    float c[16];

    Matrix();
    Matrix(float m0, float m1, float m2, float m3, float m4, float m5, float m6, float m7,
            float m8, float m9, float m10, float m11, float m12, float m13, float m14, float m15);
    ~Matrix() {};
};

Vector operator * (const Vector& v, const Matrix& m);
ostream& operator << (ostream& os, const Matrix& m);

#endif

