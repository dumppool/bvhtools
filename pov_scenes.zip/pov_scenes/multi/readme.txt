
Export a main include file all.inc, animation settings file all.ini and
frame include files for each shot from WX Motion Capture Viewer 2.
