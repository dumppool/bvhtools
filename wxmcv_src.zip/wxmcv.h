///////////////////////////////////////////////////////////////////////////
//
// wxmcv.h
//
// Purpose:   Declarations for wxWindows user interface of WX Motion Capture Viewer
//
// Created:   Jaroslav Semancik, 06/05/2003
//
///////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////
// classes declarations
///////////////////////////////////////////////////////////////////////////

class MyApp: public wxApp
{
public:
    virtual bool OnInit();
};


class MyFrame: public wxFrame
{
public:
    bool m_cycle;   // cycle animation?
    bool m_fwd;     // forward or backward playing?

    MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size);
    void SetDefaults();
    void StopAnimation();
    bool SaveFrame(wxCommandEvent& event);
    bool ExportFrame(wxCommandEvent& event);

    void OnOpen(wxCommandEvent& event);
    void OnQuit(wxCommandEvent& event);
    void OnBack(wxCommandEvent& event);
    void OnBackOne(wxCommandEvent& event);
    void OnPause(wxCommandEvent& event);
    void OnFwd(wxCommandEvent& event);
    void OnFwdOne(wxCommandEvent& event);
    void OnGoToFirstFrame(wxCommandEvent& event);
    void OnResetView(wxCommandEvent& event);
    void OnToggleCycle(wxCommandEvent& event);
    void OnToggleSolid(wxCommandEvent& event);
    void OnToggleToolbar(wxCommandEvent& event);
    void OnToggleStatusbar(wxCommandEvent& event);
    void OnRecord(wxCommandEvent& event);
    void OnExport(wxCommandEvent& event);
    void OnAbout(wxCommandEvent& event);

private:
    wxMenuBar *m_menuBar;
    wxToolBar *m_toolBar;
    wxStatusBar *m_statusBar;
    wxTimer *m_timer;

    bool m_opened;                  // is a motion file opened?
    string m_bvhpath, m_bvhname;    // path and name of the opened .bvh file
    string m_name;                  // name without .bvh extension
    string m_recpath, m_exppath;    // output paths for recording and exporting

    // stuff for animation recording
    wxWindowDC *m_canvasDC;
    wxMemoryDC m_memoryDC;
    wxBitmap m_bitmap;
    wxSize m_bitmap_size;
    wxImage m_image;

    // private methods
    void build_menu();
    void recreate_tool_bar();
    void recreate_status_bar();
    void enable_animation_tools();
    void strip_extension(string& name, const string& ext);
    bool create_blob_file();
    bool create_ini_file();
    string frame_filename(const string& path, const string& name, const string& ext);
    void write_frame_header(ofstream& file);

    DECLARE_EVENT_TABLE()
};


class AboutDialog: public wxDialog
{
public:
    AboutDialog(wxWindow *parent);
    virtual ~AboutDialog() { }

private:

};

///////////////////////////////////////////////////////////////////////////
// constants
///////////////////////////////////////////////////////////////////////////

enum
{
    ID_OPEN = wxID_OPEN,
    ID_QUIT = wxID_EXIT,
    ID_ABOUT = wxID_ABOUT,

    ID_BACK,
    ID_BACK_ONE,
    ID_PAUSE,
    ID_FWD_ONE,
    ID_FWD,
    ID_GO_TO_FIRST_FRAME,
    ID_TOGGLE_CYCLE,
    ID_RECORD,
    ID_EXPORT,

    ID_TOGGLE_SOLID,
    ID_RESET_VIEW,
    ID_TOGGLE_TOOLBAR,
    ID_TOGGLE_STATUSBAR,

    ID_TOOLBAR,

    ID_TIMER_FWD,
    ID_TIMER_BACK,
    ID_TIMER_RECORDING,
    ID_TIMER_EXPORTING
};


///////////////////////////////////////////////////////////////////////////
// global variables related to user interface
///////////////////////////////////////////////////////////////////////////

extern "C++" MyFrame *mainFrame;

